<html>
	<head>
        <link rel="stylesheet" type="text/css" href="yo.css">
        <script>
            function validate(){
                var title=document.announcement.title;
                var content=document.announcement.content;
                var society=document.announcement.society;
                var uname=document.announcement.uname;
                var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
                var numbers = /^[0-9]+$/;
                var alphabets = /^[A-Za-z ]+$/;
                if(title.value == "")
			     {
				    alert("Please enter the title\n");
                     title.focus();
				    return false;
			     }
                if(content.value == "")
			     {
				    alert("Please add some content\n");
                     content.focus();
				    return false;
			     }
                if(society.value == "")
			     {
				    alert("Please select the society\n");
                     society.focus();
				    return false;
			     }
                
                if(uname.value.match(" ")){
                    alert("User Name Should not contain spaces");
                    uname.focus();
                    return false;
                }
                 for (var i = 0; i < uname.value.length; i++) {
                    if (iChars.indexOf(uname.value.charAt(i)) != -1) {
                        alert ("Member User Name Cannot Contain special characters");
                        uname.focus();
                        return false;
                    }
                }
                if(title.value.match(numbers))  
                {  
                    alert("title Should Contain Alphabets");
                    title.focus();
                    return false;
                }
                if(uname.value.match(numbers))  
                {  
                    alert("User Name Should Contain Alphabets");
                    uname.focus();
                    return false;
                }
                if(title.value.length>30){
                    alert("Name Cannot Contain more than 30 characters");
                    title.focus();
                    return false;
                }
                if(content.value.length>300){
                    alert("User Name Cannot Contain more than 300 characters");
                    uname.focus();
                    return false;
                }
                if(uname.value.length>20){
                    alert("Member User Name cannot Contain more than 20 characters");
                    pass.focus();
                    return false;
                }
                if(society.value == "all" && uname.value != ""){
                    alert("Please select the society to which the member belongs");
                    society.focus();
                    return false;
                }
                return true;
            }
        </script>
		
	</head>
	<body>

	<form name="announcement" action="submitannouncement.php" method="post">
	<center>
	
		<h3>Make An Announcement</h3>
		
		<table>
             <tr>
                    <td colspan="2">
                        <?php
			                 if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
			                     echo '<ul class="err">';
			                     foreach($_SESSION['ERRMSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['ERRMSG_ARR']);
			                 }
                            if( isset($_SESSION['MSG_ARR']) && is_array($_SESSION['MSG_ARR']) && count($_SESSION['MSG_ARR']) >0 ) {
			                     echo '<ul class="msg">';
			                     foreach($_SESSION['MSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['MSG_ARR']);
			                 }
		                  ?>
                    </td>
                </tr>
            <tr>
                <td>Title*:</td><td><input type="text" name="title"></td>
            </tr>
		
			<tr>
				<td>Content*:</td><td><textarea name="content" rows="4" cols="50"></textarea></td>
			</tr>
			<tr>
                <td>Society*:</td>
                <td>
                    <select name="society">
                        <option value="">---</option>
                        <option value="all">All Societies</option>
                        <?php
			                 $con=mysqli_connect("localhost","root","","society");
			                 $result=mysqli_query($con,"SELECT * FROM `society`");
			                 while($row=mysqli_fetch_array($result))
			                 {
                                 echo "<option value='";		
                                 echo $row["society_name"];
                                 echo "'>";		
                                 echo $row["society_name"];
                                 echo ": ";
                                 echo $row["society_locality"];
                                 echo "</option>";		
			                 }
                            mysqli_close($con);
		                  ?>	
                    </select>
                </td>
            </tr>
            <tr>
                <td>Member User Name:</td><td><input type="text" name="uname"></td>
            </tr>
			<tr>
				<td></td><td><input type="submit" value="Submit" onClick="return validate()"></td>
			</tr>

		</table>
	
	</center>
	</form>
	</body>
</html>