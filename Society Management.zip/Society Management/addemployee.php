<html>
	<head>
		<link rel="stylesheet" type="text/css" href="yo.css">
        <script>
                function validate(){
                    var name=document.signup4.textomg;
                    var society=document.signup4.selsoc;
                    var address=document.signup4.textadd;
                    var contact=document.signup4.textcon;
                    var contact2=document.signup4.textcon2;
                    var email=document.signup4.texte;
                    var selcat=document.signup4.selc;
                    var txtcat=document.signup4.textc;
                    var iChars = "!@#$%^&*()+=-[]\\;,./{}|\":<>?_";
                    var iChars2 = "!@#$%^*()+=-[]\\;/{}|:<>\"?_";
                    var iChars3 = "!#$%^&*()+=-[]\\;,/{}|\":<>?";
                    var numbers = /^[0-9]+$/;
                    var alphabets = /^[A-Za-z ]+$/;
                    if(society.value == ""){
                        alert("Please Select Society\n");
                        society.focus();
                        return false;
                    } 
                    if (name.value == "")
                    {
				        alert("Please enter name!\n");
                        name.focus();
				        return false;
                    }
                    if (contact.value == ""){
				        alert("Please enter contact number!\n");
                        contact.focus();
				        return false;
			         }
                    if(selcat.value == "" && txtcat.value == ""){
                        alert("Please select a category or enter a new category");
                        selcat.focus();
                        return false;
                    }
                    if(contact.value.match(" ")){
                        alert("Contact number cannot contain spaces");
                        contact.focus();
                        return false;
                    }
                    
                    for (var i = 0; i < name.value.length; i++) {
                        if (iChars.indexOf(name.value.charAt(i)) != -1) {
                            alert ("Name Can only contain \"\'\" and alphabets ");
                            name.focus();
                            return false;
                        }
                    }
                 
                    if(!(name.value.match(alphabets)))  {  
                        alert("Name Should not contain Numbers");
                        name.focus();
                        return false;
                    }
                    if(address.value.match(numbers))  {  
                        alert("Address cannot contain only numbers");
                        address.focus();
                        return false;
                    }
                    if(!(contact.value.match(numbers)))  {  
                        alert("Contact number cannot contain alphabets or special characters");
                        contact.focus();
                        return false;
                    }
                    if(name.value.length>30){
                        alert("Name Cannot Contain more than 30 characters");
                        name.focus();
                        return false;
                    }
                         
                    if(contact.value.length>10){
                        alert("Contact Number Cannot Contain more than 10 digits");
                        contact.focus();
                        return false;
                    }
                    if(txtcat.value.length>20){
                        alert("Category cannot contain more than 20 chatacters");
                        txtcat.focus();
                        return false;
                    }
                    if(name.value.length<5){
                        alert("Name Cannot Contain less than 5 characters");
                        name.focus();
                        return false;
                    }
                     
                    if(contact.value.length<10){
                        alert("Contact Number Cannot Contain less than 10 digits");
                        contact.focus();
                        return false;
                    }
                    if(address.value != ""){
                        for (var i = 0; i < address.value.length; i++) {
                            if (iChars2.indexOf(address.value.charAt(i)) != -1) {
                                alert ("Address can only contain \"& , . \" and alphabets");
                                address.focus();
                                return false;
                            }
                        } 
                        if(address.value.length>200){
                            alert("Address Cannot Contain more than 200 characters");
                            address.focus();
                            return false;
                        }
                        if(address.value.length<15){
                            alert("address Cannot Contain less than 15 characters");
                            address.focus();
                            return false;
                        }
                    }
                    if(contact2.value != ""){
                        if(contact2.value.match(" ")){
                            alert("Contact number cannot contain spaces");
                            contact2.focus();
                            return false;
                        }
                        if(!(contact2.value.match(numbers)))  {  
                            alert("Contact number cannot contain alphabets or special characters");
                            contact2.focus();
                            return false;
                        }
                        if(contact2.value.length>10){
                            alert("Contact Number Cannot Contain more than 10 digits");
                            contact2.focus();
                            return false;
                        }
                        if(contact2.value.length<10){
                            alert("Contact Number Cannot Contain less than 10 digits");
                            contact2.focus();
                            return false;
                        }
                    }
                    if(email.value != ""){
                        if(email.value.match(" ")){
                            alert("Email cannot contain spaces");
                            email.focus();
                            return false;
                        }
                        for (var i = 0; i < email.value.length; i++) {
                            if (iChars3.indexOf(email.value.charAt(i)) != -1) {
                                alert ("Email can only contain \"_ @ .\", alphabets and numbers");
                                email.focus();
                                return false;
                            }
                        }
                        if(!(email.value.match("@")))  {  
                            alert("Please Enter a vlaid email address.");
                            email.focus();
                            return false;
                        }
                        if(!(email.value.match(".")))  {  
                            alert("Please Enter a vlaid email address.");
                            email.focus();
                            return false;
                        }
                        if(email.value.length>40){
                            alert("email Cannot Contain more than 40 characters");
                            email.focus();
                            return false;
                        }
                        if(email.value.length<10){
                            alert("email Cannot Contain less than 10 characters");
                            email.focus();
                            return false;
                        }
                    }
                    if(selcat.vlaue != "" && txtcat.value != "")
                        selcat.vlaue="";
                    return true;    
                }
         </script>
	</head>
    
	<body>

		<form name="signup4" action="submitemployee.php" method="post" >
		<center>

		<h2> Add Workman Contact</h2>
			<table>
                 <tr>
                    <td colspan="2">
                        <?php
			                 if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
			                     echo '<ul class="err">';
			                     foreach($_SESSION['ERRMSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['ERRMSG_ARR']);
			                 }
                            if( isset($_SESSION['MSG_ARR']) && is_array($_SESSION['MSG_ARR']) && count($_SESSION['MSG_ARR']) >0 ) {
			                     echo '<ul class="msg">';
			                     foreach($_SESSION['MSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['MSG_ARR']);
			                 }
		                  ?>
                    </td>
                </tr>
                <tr>
					<td>Select Society*:</td>
                    <td>
                        <select name="selsoc">
                            <option value="">---</option>
                            <option value="all">All Societies</option>
                            <?php
			                     $con=mysqli_connect("localhost","root","","society");
			                     $result=mysqli_query($con,"SELECT * FROM `society`");
			                     while($row=mysqli_fetch_array($result))
			                     {
				                    echo "<option value='";		
				                    echo $row["society_name"];
				                    echo "'>";		
				                    echo $row["society_name"];
				                    echo ": ";
				                    echo $row["society_locality"];
				                    echo "</option>";		
			                     }
                                mysqli_close($con);
		                      ?>	
                        </select>
                    </td>
				</tr>

				<tr>
					<td>Name*:</td>
					<td><input type="text" name="textomg"></td>
				</tr>	

				
				<tr>
					<td>Gender:</td>
					<td><select name="sel2">
                        <option value="">---</option>
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					     </select></td>
				</tr>	

				
				<tr>
					<td>Address:</td>
					<td><textarea rows="4" cols="50" name="textadd"></textarea> </td>
				</tr>

				<tr>
					<td>Contact Number*:</td>
					<td><input type="text" name="textcon"></td>
				</tr>
                <tr>
					<td>Contact Number 2:</td>
					<td><input type="text" name="textcon2"></td>
				</tr>
				<tr>
					<td>Email Address:</td>
					<td><input type="text" name="texte"></td>
				</tr>
                <tr>
					<td>Choose Category:</td>
					<td><select name="selc">
                        <option value="">---</option>
						<?php
			                     $con=mysqli_connect("localhost","root","","society");
			                     $result=mysqli_query($con,"SELECT `category_name` FROM `category`");
			                     while($row=mysqli_fetch_array($result))
			                     {
				                    echo "<option value='";		
				                    echo $row["category_name"];
				                    echo "'>";		
				                    echo $row["category_name"];
				                    echo "</option>";		
			                     }
                                mysqli_close($con);
		                      ?>
					     </select></td>
				</tr>
                <tr>
                    <td>OR</td><td></td>
                </tr>
                <tr>
                    <td>Enter New Category:</td>
                    <td><input type="text" name="textc"></td>
                </tr>
				<tr>
					<td></td>
					<td><input type="submit" value="Register" onClick="return validate()"><input type="reset" value="Clear"></td>
				</tr>	
			</table>
            </center>
        </form>			
	</body>
</html>