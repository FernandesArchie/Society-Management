<html>
    <head>
        <link rel="stylesheet" type="text/css" href="yo.css">
        <script>
            function validate(){
                var fname=document.addfacility.fname;
                var society=document.addfacility.society;
                var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
                var numbers = /^[0-9]+$/;
                var alphabets = /^[A-Za-z ]+$/;
                if(fname.value == "")
			     {
				    alert("Please enter the facility name\n");
                     fname.focus();
				    return false;
			     }
                if(society.value == "")
			     {
				    alert("Please Select a Society\n");
                     society.focus();
				    return false;
			     }
                
                 for (var i = 0; i < fname.value.length; i++) {
                    if (iChars.indexOf(fname.value.charAt(i)) != -1) {
                        alert ("Facility Name Cannot Contain special characters");
                        uname.focus();
                        return false;
                    }
                }
                if(fname.value.match(numbers))  
                {  
                    alert("Facility name Should Contain Alphabets");
                    fname.focus();
                    return false;
                }
                if(fname.value.length>30){
                    alert("Facility Name Cannot Contain more than 30 characters");
                    fname.focus();
                    return false;
                }
                return true;
            }
        </script>
    </head>
    <body>

	<form name="addfacility" action="submitfacility.php" method="post">
	<center>
	
		<h3>Add a Facility</h3>
		
		<table>
             <tr>
                    <td colspan="2">
                        <?php
			                 if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
			                     echo '<ul class="err">';
			                     foreach($_SESSION['ERRMSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['ERRMSG_ARR']);
			                 }
                            if( isset($_SESSION['MSG_ARR']) && is_array($_SESSION['MSG_ARR']) && count($_SESSION['MSG_ARR']) >0 ) {
			                     echo '<ul class="msg">';
			                     foreach($_SESSION['MSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['MSG_ARR']);
			                 }
		                  ?>
                    </td>
                </tr>
            <tr>
                <td>Name:</td><td><input type="text" name="fname"></td>
            </tr>
		
			<tr>
                <td>Society:</td>
                <td>
                    <select name="society">
                        <option value="">---</option>
                        <option value="0">All Societies</option>
                        <?php
			                 $con=mysqli_connect("localhost","root","","society");
			                 $result=mysqli_query($con,"SELECT * FROM `society`");
			                 while($row=mysqli_fetch_array($result))
			                 {
                                 echo "<option value='";		
                                 echo $row["society_id"];
                                 echo "'>";		
                                 echo $row["society_name"];
                                 echo ": ";
                                 echo $row["society_locality"];
                                 echo "</option>";		
			                 }
                            mysqli_close($con);
		                  ?>	
                    </select>
                </td>
            </tr>
			<tr>
				<td></td><td><input type="submit" value="Submit" onClick="return validate()"></td>
			</tr>

		</table>
	
	</center>
	</form>
	</body>
</html>