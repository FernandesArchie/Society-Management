<html>
	<head>
		<link rel="stylesheet" type="text/css" href="yo.css">
        <script>
            function validate(){
                var reason=document.meeting.textreason;
                var location=document.meeting.textloc;
                var date=document.meeting.date;
                var datec = new Date(date.value);
                var today = new Date();
                var now = new Date(2011,0,1,today.getHours(),today.getMinutes(),today.getSeconds());
                today.setHours(0, 0, 0, 0);
                var time = document.meeting.dtime;
                var timec = new Date('1/1/2011 '+time.value+':00');
                var type=document.meeting.seltype1;
                var agenda=document.meeting.txtag;
                var society=document.meeting.society;
                var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
                var numbers = /^[0-9]+$/;
                var alphabets = /^[A-Za-z ]+$/;
                if(reason.value == "")
			     {
				    alert("Please enter the reason for the meeting\n");
                     reason.focus();
				    return false;
			     }
                if(location.value == "")
			     {
				    alert("Please enter the location\n");
                     location.focus();
				    return false;
			     }
                if(date.value == "")
			     {
				    alert("Please Select a date\n");
                    date.focus();
				    return false;
			     }
                if(time.value == "")
			     {
				    alert("Please Select time for the meeting\n");
                    time.focus();
				    return false;
			     }
                if(type.value == "")
			     {
				    alert("Please Select The Type of Meeting\n");
                    type.focus();
				    return false;
			     }
                if(agenda.value == "")
			     {
				    alert("Please enter the agenda\n");
                    agenda.focus();
				    return false;
			     }
                if(society.value == "")
			     {
				    alert("Please Select the society\n");
                    society.focus();
				    return false;
			     }

                if(reason.value.match(numbers))  
                {  
                    alert("Reason Should Contain Alphabets");
                    reason.focus();
                    return false;
                }
                if(location.value.match(numbers))  
                {  
                    alert("location Should Contain Alphabets");
                    location.focus();
                    return false;
                }
                if(agenda.value.match(numbers))  
                {  
                    alert("agenda Should Contain Alphabets");
                    agenda.focus();
                    return false;
                }
                if(reason.value.length>50){
                    alert("reason Cannot Contain more than 50 characters");
                    reason.focus();
                    return false;
                }
                if(location.value.length>50){
                    alert("reason Cannot Contain more than 50 characters");
                    location.focus();
                    return false;
                }
                if(agenda.value.length>300){
                    alert("agenda Cannot Contain more than 300 characters");
                    agenda.focus();
                    return false;
                }
                if(datec < today){
                    alert("Cannot select date prior to todays date");
                    date.focus();
                    return false;
                }
                if((datec.getDate() == today.getDate()) && (datec.getMonth() == today.getMonth()) && (datec.getFullYear() == today.getFullYear())){
                    if(timec < now){
                        alert("Cannot set time prior to current time");
                        time.focus();
                        return false;
                    }
                }
                return true;
            }
        </script>
	</head>

	<body>
	<form name="meeting" action="submitmeeting.php" method="post" >
		<center>
		<h2>Schedule a Meeting</h2>
			<table>
                <tr>
                    <td colspan="2">
                        <?php
			                 if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
			                     echo '<ul class="err">';
			                     foreach($_SESSION['ERRMSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['ERRMSG_ARR']);
			                 }
                            if( isset($_SESSION['MSG_ARR']) && is_array($_SESSION['MSG_ARR']) && count($_SESSION['MSG_ARR']) >0 ) {
			                     echo '<ul class="msg">';
			                     foreach($_SESSION['MSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['MSG_ARR']);
			                 }
		                  ?>
                    </td>
                </tr>
				<tr>
					<td>Reason:</td>
					<td><input type="text" name="textreason"></td>
				</tr>	

				<tr>
					<td>Location:</td>
					<td><input type="text" name="textloc"></td>
				</tr>	
                <tr>
					<td>Date:</td>
						<td><input type="date" name="date"></td>
				</tr>
				<tr>
					<td>Time:</td>
						<td><input type="time" name="dtime"></td>
				</tr>

				<tr>
					<td>Type:</td>
					<td><select name="seltype1">
                        <option value="">---</option>
						<option value="Member">Member</option>
						<option value="General">General</option>
					     </select></td>
				</tr>

				<tr>
					<td>Agenda:</td>
					<td><textarea name="txtag" rows="4" cols="50"></textarea></td>
				</tr>
				<tr>
                <td>Society:</td>
                <td>
                    <select name="society">
                        <option value="">---</option>
                        <option value="0">All Societies</option>
                        <?php
			                 $con=mysqli_connect("localhost","root","","society");
			                 $result=mysqli_query($con,"SELECT * FROM `society`");
			                 while($row=mysqli_fetch_array($result))
			                 {
                                 echo "<option value='";		
                                 echo $row["society_id"];
                                 echo "'>";		
                                 echo $row["society_name"];
                                 echo ": ";
                                 echo $row["society_locality"];
                                 echo "</option>";		
			                 }
                            mysqli_close($con);
		                  ?>	
                    </select>
                </td>
            </tr>
				<tr>
					<td></td>
					<td><input type="submit" value="Submit" onclick="return validate()"><input type="reset" value="Clear"></td>
				</tr>	
			</table>
	</center>
		
	</form>			
	</body>
</html>