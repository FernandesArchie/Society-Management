<html>
	<head>
		<link rel="stylesheet" type="text/css" href="yo.css">
        <script>
            function validate() {
                var name = document.form.text0;
                var society = document.form.selsoc;
                var gender = document.form.sel2;
                var type = document.form.memtyp;
                var fvno = document.form.textloc;
                var psno = document.form.textps;
                var vrno = document.form.textvrn;
                var user = document.form.textuname;
                var pass = document.form.textp;
                var cpass = document.form.textr;
                var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?_";
                var iChars0 = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
                var iChars1 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?_";
                var iChars2 = "!@#$%^&*()+=[]\';/{}|\"<>?";
                var numbers = /^[0-9]+$/;
                var alphabets = /^[A-Za-z ]+$/;
                if (name.value == "")
			     {
				    alert("Please enter Member name\n");
                    name.focus();
				    return false;
			     }
                if (fvno.value == "")
			     {
				    alert("Please enter the Flat / Villa Number\n");
                     fvno.focus();
				    return false;
			     }
                if (user.value == "")
			     {
				    alert("Please enter the user name\n");
                     user.focus();
				    return false;
			     }
                if (pass.value == "")
			     {
				    alert("Please enter the password\n");
                     pass.focus();
				    return false;
			     }
                if (cpass.value == "")
			     {
				    alert("Please confirm the password\n");
                     cpass.focus();
				    return false;
			     }
                if (!(vrno.value == "")){
                    if(psno.value == ""){
                        alert("Vehicle Cannot be registered without parking spot number.\n");
                        return false;
                    }
                }
                if (user.value.match(" ")) {
                    alert("User Name Should not contain spaces");
                    user.focus();
                    return false;
                }
                if(fvno.value.match(" ")) {
                    alert("Flat / Villa number Should not contain spaces");
                    fvno.focus();
                    return false;
                }
                if(psno.value.match(" ")) {
                    alert("Parking Spot number Should not contain spaces");
                    psno.focus();
                    return false;
                }
                for (var i = 0; i < name.value.length; i++) {
                    if (iChars.indexOf(name.value.charAt(i)) != -1) {
                        alert ("Name Cannot Contain special characters and \"_\"");
                        name.focus();
                        return false;
                    }
                }
                for (var i = 0; i < fvno.value.length; i++) {
                    if (iChars2.indexOf(fvno.value.charAt(i)) != -1) {
                        alert ("Flat / Villa Number can only contain Alphabets, Numbers and these characters:\n\"-\\,.:_\"");
                        fvno.focus();
                        return false;
                    }
                }
                for (var i = 0; i < vrno.value.length; i++) {
                    if (iChars1.indexOf(vrno.value.charAt(i)) != -1) {
                        alert ("Vehicle Registration Number can only contain Alphabets, Numbers and these characters:\n\".\"");
                        vrno.focus();
                        return false;
                    }
                }
                for (var i = 0; i < user.value.length; i++) {
                    if (iChars0.indexOf(user.value.charAt(i)) != -1) {
                        alert ("User Name Cannot Contain special characters");
                        user.focus();
                        return false;
                    }
                }
                if(!(name.value.match(alphabets)))  
                {  
                    alert("Name Should not contain Numbers");
                    name.focus();
                    return false;
                }
                if(fvno.value.match(numbers))  
                {  
                    alert("Flat / Villa Number Should Contain Alphabets");
                    fvno.focus();
                    return false;
                }
                if (psno.value.match(numbers))  
                {  
                    alert("Parking Spot Number Should Contain Alphabets");
                    psno.focus();
                    return false;
                }
                if (vrno.value.match(numbers))  
                {  
                    alert("Vehicle Registration Number Should Contain Alphabets");
                    vrno.focus();
                    return false;
                }
                if(user.value.match(numbers))  
                {  
                    alert("User Name Should Contain Alphabets");
                    user.focus();
                    return false;
                }
                if(name.value.length>30){
                    alert("Name Cannot Contain more than 30 characters");
                    name.focus();
                    return false;
                }
                if (fvno.value.length>5){
                    alert("Flat / Villa Number Cannot Contain more than 5 characters");
                    fvno.focus();
                    return false;
                }
                if (psno.value.length>5){
                    alert("Parking Spot Number Cannot Contain more than 5 characters");
                    psno.focus();
                    return false;
                }
                if (vrno.value.length>13){
                    alert("Vehicle Registration Number Cannot Contain more than 13 characters");
                    vrno.focus();
                    return false;
                }
                if (user.value.length>20){
                    alert("User Name Cannot Contain more than 20 characters");
                    user.focus();
                    return false;
                }
                if (pass.value.length>30){
                    alert("Password cannot Contain more than 30 characters");
                    pass.focus();
                    return false;
                }
                if (pass.value.length<6){
                    alert("Password cannot Contain less than 6 characters");
                    pass.focus();
                    return false;
                }
                if (pass.value != cpass.value){
                    alert("Passwords Dont Match");
                    pass.focus();
                    cpass.focus();
                    return false;
                }
                return true;
            }
        </script>
	</head>
	<body>
	<center>
		<form name="form" action="submitmember.php" method="post">
		<h2> Add A Member</h2>
			<table>
                 <tr>
                    <td colspan="2">
                        <?php
			                 if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
			                     echo '<ul class="err">';
			                     foreach($_SESSION['ERRMSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['ERRMSG_ARR']);
			                 }
                            if( isset($_SESSION['MSG_ARR']) && is_array($_SESSION['MSG_ARR']) && count($_SESSION['MSG_ARR']) >0 ) {
			                     echo '<ul class="msg">';
			                     foreach($_SESSION['MSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['MSG_ARR']);
			                 }
		                  ?>
                    </td>
                </tr>
				<tr>
					<td>Name:</td>
					<td><input type="text" name="text0"></td>
				</tr>	

				<tr>
					<td>Select Society:</td>
                    <td>
                        <select name="selsoc">
                            <?php
			                     $con=mysqli_connect("localhost","root","","society");
			                     $result=mysqli_query($con,"SELECT * FROM `society`");
			                     while($row=mysqli_fetch_array($result))
			                     {
				                    echo "<option value='";		
				                    echo $row["society_id"];
				                    echo "'>";		
				                    echo $row["society_name"];
				                    echo ": ";
				                    echo $row["society_locality"];
				                    echo "</option>";		
			                     }
                                mysqli_close($con);
		                      ?>	
                        </select>
                    </td>
				</tr>

				<tr>
					<td>Gender:</td>
					<td><select name="sel2">
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					     </select></td>
				</tr>

				<tr>
					<td>Type Of Member:</td>
					<td><select name="memtyp">
						<option value="Owner">Owner</option>
						<option value="Tenant">Tenant</option>
					     </select></td>
				</tr>	

				<tr>
					<td>Flat / Villa Number:</td>
					<td><input type="text" name="textloc"></td>
				</tr>

				<tr>
					<td>Parking Spot Number:</td>
					<td><input type="text" name="textps"></td>
				</tr>

				<tr>
					<td>Vehicle Registration Number:</td>
					<td><input type="text" name="textvrn"></td>
				</tr>

				<tr>
					<td>User Name:</td>
					<td><input type="text" name="textuname"></td>
				</tr>

				<tr>
					<td>Password:</td>
					<td><input type="password" name="textp"></td>
				</tr>

				<tr>
					<td>Confirm Password:</td>
					<td><input type="password" name="textr"></td>
				</tr>
				
				<tr>
					<td></td>
					<td><input type="submit" value="Register" onClick="return validate()"><input type="reset" value="Clear"></td>
				</tr>	
			</table>
		</form>
	</center>				
	</body>
</html>