<html>
	<head>
		<link rel="stylesheet" type="text/css" href="yo.css">
        <script>
            function validate()
            {
                var a=document.signup.text1;
                var b=document.signup.textloc;
                var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
                var iChars2 = "!@#$%^&*()+=[]\';{}|\"<>?";
                var numbers = /^[0-9]+$/;
                if(a.value == "")
			     {
				    alert("Please enter the society name\n");
                     a.focus();
				    return false;
			     }
                if(b.value == "")
			     {
				    alert("Please enter the address\n");
                     b.focus();
				    return false;
			     }
                for (var i = 0; i < a.value.length; i++) {
                    if (iChars.indexOf(a.value.charAt(i)) != -1) {
                        alert ("Society Name Cannot Contain these characters:\n!@#$%^&*()+=-[]\\\';,./{}|\":<>?");
                        a.focus();
                        return false;
                    }
                }
                 for (var i = 0; i < b.value.length; i++) {
                    if (iChars2.indexOf(b.value.charAt(i)) != -1) {
                        alert ("Society Address Cannot Contain these characters:\n!@#$%^&*()+=[]\';{}|\"<>?");
                        b.focus();
                        return false;
                    }
                }  
                if(a.value.match(numbers))  
                {  
                    alert("Society Name Should Contain Alphabets");
                    a.focus();
                    return false;
                }
                if(b.value.match(numbers))  
                {  
                    alert("Society Address Should Contain Alphabets");
                    b.focus();
                    return false;
                }
                if(a.value.length<3){
                    alert("Society Name Cannot Contain less than 3 characters");
                    a.focus();
                    return false;
                }
                if(b.value.length<5){
                    alert("Society Address Cannot Contain more than 3 characters");
                    b.focus();
                    return false;
                }
                if(a.value.length>30){
                    alert("Society Name Cannot Contain more than 30 characters");
                    a.focus();
                    return false;
                }
                if(b.value.length>100){
                    alert("Society Address Cannot Contain more than 100 characters");
                    b.focus();
                    return false;
                }
                return true;
            }
        </script>
	</head>

	<body>
		<center>
		<form name="signup" action="submitsociety.php" method="post" >
		<h2>Add A Society </h2>
			<table>
                <tr>
                    <td colspan="2">
                        <?php
			                 if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
			                     echo '<ul class="err">';
			                     foreach($_SESSION['ERRMSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['ERRMSG_ARR']);
			                 }
                            if( isset($_SESSION['MSG_ARR']) && is_array($_SESSION['MSG_ARR']) && count($_SESSION['MSG_ARR']) >0 ) {
			                     echo '<ul class="msg">';
			                     foreach($_SESSION['MSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['MSG_ARR']);
			                 }
		                  ?>
                    </td>
                </tr>
				<tr>
					<td>Society Name:</td>
					<td><input type="text" name="text1"></td>
				</tr>	

				<tr>
					<td>Address:</td>
                    <td><textarea rows="4" cols="50" name="textloc"></textarea></td>
				</tr>	
				
				<tr>
					<td></td>
					<td><input type="submit" value="Submit" onClick="return validate()"><input type="reset" value="Clear"></td>
				</tr>	
			</table>
		</form>
	</center>
	</body>
</html>