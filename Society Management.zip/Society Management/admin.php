<?php
	require_once('auth.php');
    if($_SESSION['SESS_ADMIN']=="no"){
        header("location: member.php");
			exit();}
?>
<html>
	<head>

				<link rel="stylesheet" type="text/css" href="yo.css">
	</head>
	<body>
<center>
	<fieldset id="col1">
		<center><img src="yo.png" width="80px" height="80px">
		<h3> Society Management System</h3>
		</center>
	</fieldset>
    
    <fieldset id="col2">
	<fieldset id="col" >
			<ul class="menu">
		      <li><a href="admin.php">Home</a></li>
                <li><a href='#'>Announcements</a>
                <ul class="large">
				    <li><a href="?con=aa">Add Announcements</a></li>
				    <li><a href="?con=sra">View / Remove Announcements</a></li>
                  </ul>	
		      </li>
		      <li><a href="#">Meetings</a>
                <ul class="large">
                    <li><a href="?con=am">Add Meeting</a></li>
                    <li><a href="?con=vrm">View / Remove Meetings</a></li>
                  </ul>
                </li>
                <li><a href="#">Members</a>
                <ul class='medium'>
                    <li><a href="?con=adm">Add Member</a></li>
                    <li><a href="?con=erm">Edit / Remove Members</a></li>
                    <li><a href="?con=ap">Allot / Recant Parking</a></li>
                   </ul>
                </li>
		      <li><a href="#">Societies</a>
                <ul class="medium">
                  <li><a href="?con=as">Add Society</a></li>
                    <li><a href="?con=ers">Remove / Edit Society</a></li>
                  </ul>
                </li>
                <li><a href="#">Bookings</a>
                <ul class='small'>
                    <li><a href="?con=vb">View Bookings</a></li>
                    </ul>
                </li>
                 <li><a href="#">Facilities</a>
                <ul class='medium'>
                    <li><a href="?con=af">Add Facility</a></li>
                    <li><a href="?con=erf">Edit / Remove Facilities</a></li>
                    </ul>
                </li>
                <li><a href="#">Contacts</a>
                <ul class="medium">
                    <li><a href='?con=ac'>Add Contact</a></li>
                    <li><a href='?con=erc'>Edit / Remove Contact</a></li>
                    </ul>
                </li>
                <li><a href="#" style="width:500px"></a></li>
                <li><a href="logout.php">Log Out</a></li>
            </ul>
	</fieldset>
	<?php
		if(isset($_REQUEST['con'])){
		  switch($_REQUEST['con']){
              case 'aa':include("addannouncement.php");
                  break;
              case 'am':include("addmeeting.php");
                  break;
              case 'adm':include("addmember.php");   
                  break;
              case 'as':include("addsociety.php");
                  break;
              case 'vb':include("dispbookings.php");
                  break;
              case 'af':include("addfacility.php");
                  break;
              case 'ac':include("addemployee.php");
                  break;
              case 'vrm':include("selectmeeting.php");
                  break;
              case 'sra':include("selectannouncement.php");
                  break;
              case 'erm':include("selectmember.php");
                  break;
              case 'rm':include("removemember.php");
                  break;
              case 'ap':include("allotparking.php");
                  break;
              case 'sp':include("submitparking.php");
                  break;
              case 'ers':include("selectsociety.php");
                  break;
              case 'rs':include("removesociety.php");
                  break;
              case 'erf':include("selectfacility.php");
                  break;
              case 'rf':include("removefacility.php");
                  break;
              case 'erc':include("removecontact.php");
                  break;
		  }
        }
	?>


	</fieldset>
</center>
	
	</body>
</html>