<?php
	require_once('auth.php');
    if($_SESSION['SESS_ADMIN']=="no"){
        header("location: member.php");
			exit();}
?>
<html>
	<head>

				<link rel="stylesheet" type="text/css" href="yo.css">
	</head>
	<body>
<center>
	<fieldset id="col1">
		<center><img src="yo.png" width="80px" height="80px">
		<h3> Society Management System</h3>
		</center>
	</fieldset>
	<fieldset id="col" >
	<center>
	<table border="0" >
	<tr>
	
	<td class="l1" style="width:200"><a href="?con=an">ANNOUNCEMENTS  </a></td>
	<td class="l1" style="width:200"><a href="?con=cm">CREATE MEETING</a></td>
	
	
        
        <td class="l1" style="width:200"><a href="?con=am">ADD A MEMBER</a></td>

	
        <td class="l1" style="width:200"><a href="?con=as">ADD A SOCIETY</a></td>
	
	<td class="l1"  style="width:200"><a href="?con=vb">VIEW BOOKINGS</a></td>
	<td class="l1"  style="width:200"><a href="?con=vm">ADD CONTACTS</a></td>
	
	  <td class="l1" style="width:200"><a href="logout.php">LOG OUT</a></td>



	</tr>

</table> 

</center>
	</fieldset>
	
	<fieldset id="col2">

	<?php
		error_reporting(0);
		switch($_REQUEST['con'])
		{
			case 'an':include("addannouncement.php");
				break;
			case 'cm':include("addmeeting.php");
				break;
			case 'am':include("addmember.php");   
				break;
			case 'as':include("addsociety.php");
				break;
			case 'vb':include("dispbookings.php");
				break;
			case 'vm':include("addemployee.php");
				break;
		}
	?>


	</fieldset>
</center>
	
	</body>
</html>