<?php

unset($_SESSION['NM_ARR']);
$NM_ARR = array();
    $errflag = false;
    $con = new mysqli("localhost", "root", "", "society");
    if(!(isset($_GET['soc']))) {
        if($stmt = $con->prepare ("SELECT `member_id`, `member_name`, `member_gender`, `member_uname`, `flat_number`, `member_type`, `society_id` FROM `member` WHERE 1")){
            $stmt->execute();    // Execute the prepared query.
            $stmt->store_result();
        }
        if ($stmt->num_rows == 0) {
            $NM_ARR[] = 'There are no registered members';
            $errflag=true;
        }
    }
    else{
        $sid = $_GET['soc'];
        if($sid == '-1'){
            if($stmt = $con->prepare ("SELECT `member_id`, `member_name`, `member_gender`, `member_uname`, `flat_number`, `member_type`, `society_id` FROM `member` WHERE 1")){
                $stmt->execute();    // Execute the prepared query.
                $stmt->store_result();
            }
            if ($stmt->num_rows == 0) {
                $NM_ARR[] = 'There are no registered members';
                $errflag=true;
            }
        }
        else{
            if($stmt = $con->prepare ("SELECT `member_id`, `member_name`, `member_gender`, `member_uname`, `flat_number`, `member_type`, `society_id` FROM `member` WHERE society_id = ?")){
                $stmt->bind_param('s', $sid);
                $stmt->execute();    // Execute the prepared query.
                $stmt->store_result();
            }
            if ($stmt->num_rows == 0) {
                $NM_ARR[] = 'There are no registered members in the selected Society';
                $errflag=true;
            }
        }
    }
     if($errflag){
         $_SESSION['NM_ARR']=$NM_ARR;
        session_write_close();
    }
?>
<html>
    <head>
        <script>
            function csociety(){
                var seld = document.announcement.society.value;
                window.location.href ='admin.php?con=ap&soc=' + seld;
            }
            function validate(){
                var x = confirm('Are you sure you want to delete this parking spot?');
                return x;
            }
        </script>
    </head>
    <body>
        <form name="announcement" action="admin.php?con=sp" method="post" >
		<center>
        <div>
		<h2>Allot Parking</h2>
			<table border = '1'>                    
                <tr><th>Name</th><th>Gender</th><th>User Name</th><th>Type</th><th>Flat Number</th><th>Parking</th>
                    <th>Society:<select name = "society" onchange="csociety();">
                        <?php
                            $sid = -1;
                            if(isset($_GET['soc']))
                                $sid = $_GET['soc'];
                            echo"<option value = '-1'";
                            echo">---</option>";
                            echo"<option value = '0'";
                            if($sid == 0)
                                echo"selected";
                            echo">All Societies</option>";
                            $con2=mysqli_connect("localhost","root","","society");
			                $result=mysqli_query($con2,"SELECT * FROM `society`");
			                while($row=mysqli_fetch_array($result))
			                {
				                echo "<option value='";		
				                echo $row["society_id"]."'";
                                if($sid==$row["society_id"])
                                    echo"selected";
				                echo ">";		
				                echo $row["society_name"];
				                echo ": ";
				                echo $row["society_locality"];
				                echo "</option>";		
			                }
                            mysqli_close($con2);
		              ?>
                    </select></th><th>Allot</th>
                </tr>
                <?php
                    if( isset($_SESSION['MG_ARR']) && is_array($_SESSION['MG_ARR']) && count($_SESSION['MG_ARR']) >0 ) {
			             echo "<tr>";
                         echo'<td colspan="8">';
                         echo '<ul class="msg">';
			             foreach($_SESSION['MG_ARR'] as $msg) {
				            echo '<li>',$msg,'</li>';
				         }
                        unset($_SESSION['MG_ARR']);
			             echo '</ul>';
                         echo'</td>';
                         echo'</tr>';
			         }
			         if( isset($_SESSION['NM_ARR']) && is_array($_SESSION['NM_ARR']) && count($_SESSION['NM_ARR']) >0 ) {
			             echo "<tr>";
                         echo'<td colspan="8">';
                         echo '<ul class="err">';
                         
			             foreach($_SESSION['NM_ARR'] as $msg) {
				              echo '<li>',$msg,'</li>';
				         }
			             echo '</ul>';
                         unset($_SESSION['NM_ARR']);
                         echo'</td></tr>';
			         }
                    if( isset($_SESSION['ERR_ARR']) && is_array($_SESSION['ERR_ARR']) && count($_SESSION['ERR_ARR']) >0 ) {
			             echo "<tr>";
                         echo'<td colspan="8">';
                         echo '<ul class="err">';
                         
			             foreach($_SESSION['ERR_ARR'] as $msg) {
				              echo '<li>',$msg,'</li>';
				         }
			             echo '</ul>';
                         unset($_SESSION['ERR_ARR']);
                         echo'</td></tr>';
			         }
                ?>
                <?php
                $stmt->execute();
                $stmt->bind_result($id, $name, $gender, $uname, $fno, $type, $sid);
                while ($stmt->fetch()) {
                    echo "<tr><td>";
                    echo $name;
                    echo "</td><td>";
                    echo $gender;
                    echo "</td><td>";
                    echo $uname;
                    echo "</td><td>";
                    echo $type;
                    echo "</td><td>";
                    echo $fno;
                    $con2=mysqli_connect("localhost","root","","society");
			        $result=mysqli_query($con2,"SELECT * FROM `parking` WHERE `member_id` = ".$id);
                    echo "</td><td>";  
                    $o = true;
                    echo "<table border=\"1\">";
			         while($row=mysqli_fetch_array($result))
			         {
				      	echo "<tr><td>";	
				         echo $row["parking_number"];
                         echo " >> ";
				         if($row["parking_vnumber"] == NULL)
                             echo "----";
                         else
                             echo $row["parking_vnumber"];
                         echo "</td><td><button name='edit' type='submit' value='".$row["parking_id"]."'>Edit</button></td>";
                         echo "</td><td><button name='delete' type='submit' value='".$row["parking_id"]."' onClick='return validate()'>Delete</button></td></tr>";
                         $o = false;
			         }
                    echo "</table>";
                    mysqli_close($con2);
                    if ($o) {
                        echo "<tr><td>---->> ----</td></tr></table>";
                    }
                    if($sid == 0){
                        echo "</ul></td><td>";
                        echo "All Societies";
                    }
                    else{
                        $con1=mysqli_connect("localhost","root","","society");
			            $result=mysqli_query($con1,"SELECT * FROM `society` where society_id = ".$sid);
			            $row=mysqli_fetch_array($result);
                        echo "</td><td>";				
                        echo $row["society_name"];
                        echo ": ";
                        echo $row["society_locality"];		
			            mysqli_close($con1);
                    }
                    echo "</td><td>";
                    echo "<button name='alter' type='submit' value='".$id."'>Allot</button>";
                    echo "</td></tr>";
                }
            ?>
			</table>
            </div>
        </center>
	</form>	
	</body>
</html>