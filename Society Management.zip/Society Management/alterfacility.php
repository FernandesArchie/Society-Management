<?php
    session_start();
    $errmsg_arr = array();
	$con = new mysqli("localhost", "root", "", "society");
    $id = $_POST["id"];
    $name = $_POST["fname"];
    if($stmt0 = $con->prepare ("UPDATE `facilities` SET `facility_name`= ? WHERE `facility_id` = ?")){
        $stmt0->bind_param('ss', $name, $id);  // Bind "$name" to parameter.
        $stmt0->execute();    // Execute the prepared query.
        $errmsg_arr[] = 'Details Successfully Changed';
    }
    $_SESSION['MG_ARR'] = $errmsg_arr;
    session_write_close();
    header("location: admin.php?con=erf");
    exit();
?>