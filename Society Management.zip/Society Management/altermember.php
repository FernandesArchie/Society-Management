<?php
    session_start();
    $errmsg_arr = array();
	$con = new mysqli("localhost", "root", "", "society");
    $con1 = new mysqli("localhost", "root", "", "society");
    $id = $_POST["mid"];
    $name = $_POST["text0"];
    $gender = $_POST["sel2"];
    $pass = $_POST["textp"];
    if($stmt = $con->prepare ("SELECT `member_name`, `member_gender`, `member_pword` FROM `member` WHERE `member_id` = ? limit 1")){
        $stmt->bind_param('s', $id);  // Bind "$name" to parameter.
        $stmt->execute();// Execute the prepared query.
        $stmt->bind_result($nm, $gd, $pd);
        $stmt->fetch();
    }
    if($name == $nm && $gender == $gd && $pass == ""){
        $errmsg_arr[] = 'No Changes Made';
        $_SESSION['MG_ARR'] = $errmsg_arr;
        session_write_close();
        header("location: admin.php?con=erm");
	    exit();
    }
    else if(!($name == $nm && $gender == $gd)){
        if($stmt0 = $con1->prepare ("UPDATE `member` SET `member_name`= ?,`member_gender`= ? WHERE `member_id` = ?")){
            $stmt0->bind_param('sss', $name, $gender, $id);  // Bind "$name" to parameter.
            $stmt0->execute();    // Execute the prepared query.
            $errmsg_arr[] = 'Details Successfully Changed';
        }
    }
    if($pass != ""){
        $pas = crypt($pass); 
        if($stmt0 = $con1->prepare ("UPDATE `member` SET `member_pword`= ? WHERE `member_id` = ?")){
            $stmt0->bind_param('ss', $pas, $id);  // Bind "$name" to parameter.
            $stmt0->execute();    // Execute the prepared query.
            $errmsg_arr[] = 'Password Successfully Changed';
        }
    }
    $_SESSION['MG_ARR'] = $errmsg_arr;
    session_write_close();
    header("location: admin.php?con=erm");
    exit();
?>