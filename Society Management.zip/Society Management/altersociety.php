<?php
    session_start();
    $errmsg_arr = array();
	$con = new mysqli("localhost", "root", "", "society");
    $con0 = new mysqli("localhost", "root", "", "society");
    $con1 = new mysqli("localhost", "root", "", "society");
    $id = $_POST["id"];
    $name = $_POST["text1"];
    $address = $_POST["textloc"];
    if($stmt = $con->prepare ("SELECT `society_name`, `society_locality` FROM `society` WHERE `society_id` = ? limit 1")){
        $stmt->bind_param('s', $id);  // Bind "$name" to parameter.
        $stmt->execute();// Execute the prepared query.
        $stmt->bind_result($nm, $gd);
        $stmt->fetch();
    }
    if($stmt1 = $con0->prepare ("SELECT `society_id` FROM `society` WHERE `society_name` = ? AND `society_locality` = ? limit 1")){
        $stmt1->bind_param('ss', $name, $address);  // Bind "$name" to parameter.
        $stmt1->execute();// Execute the prepared query.
        $stmt1->store_result();
    }
    if($name == $nm && $address == $gd){
        $errmsg_arr[] = 'No Changes Made';
        $_SESSION['MG_ARR'] = $errmsg_arr;
        session_write_close();
        header("location: admin.php?con=ers");
	    exit();
    }
    if($stmt1->num_rows == 1){
        $errmsg_arr[] = 'Society Already Exists with the same name and address';
        $_SESSION['MsG_ARR'] = $errmsg_arr;
        session_write_close();
        header("location: admin.php?con=ers");
	    exit();
    }
    else if(!($name == $nm && $address == $gd)){
        if($stmt0 = $con1->prepare ("UPDATE `society` SET `society_name`= ? ,`society_locality`= ? WHERE `society_id` = ?")){
            $stmt0->bind_param('sss', $name, $address, $id);  // Bind "$name" to parameter.
            $stmt0->execute();    // Execute the prepared query.
            $errmsg_arr[] = 'Details Successfully Changed';
        }
    }
    $_SESSION['MG_ARR'] = $errmsg_arr;
    session_write_close();
    header("location: admin.php?con=ers");
    exit();
?>