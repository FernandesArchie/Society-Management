<html>
	<head>
        <link rel="stylesheet" type="text/css" href="yo.css">
    </head>
	<body>
		<?php
			$con=mysqli_connect("localhost","root","","society");
			$result=mysqli_query($con,"SELECT * FROM `announcement` WHERE 1");
			echo"<table border='1'><tr><th>announcement_id</th><th>announcement_content</th></tr>";
			while($row=mysqli_fetch_array($result))
			{
				echo "<tr><td>";		
				echo $row["announcement_id"];
				echo "</td><td>";		
				echo $row["announcement_content"];
				echo "</td></tr>";		
			}
			echo "</table>";
		?>			
	</body>
</html>

	