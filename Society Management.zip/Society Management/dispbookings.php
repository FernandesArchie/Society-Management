<html>
    <head>		<link rel="stylesheet" type="text/css" href="yo.css"></head>
	<body>
		<center>
		<?php
			$con=mysqli_connect("localhost","root","","society");
			$result=mysqli_query($con,"SELECT * FROM `bookings`");
			echo"<table border='1'><tr><th>booking_id</th><th>booking_type</th><th>booking_date</th><th>booking_reason</th></tr>";
			while($row=mysqli_fetch_array($result))
			{
				echo "<tr><td>";		
				echo $row["booking_id"];
				echo "</td><td>";		
				echo $row["booking_type"];
				echo "</td><td>";
				echo $row["booking_date"];
				echo "</td><td>";
				echo $row["booking_reason"];
				echo "</td></tr>";		
			}
			echo "</table>";
		?>	
		</center>		
	</body>
</html>
