<html>
	<head>
       		<link rel="stylesheet" type="text/css" href="yo.css"> 
    </head>
	<body>
	<center>
		<?php
			$con=mysqli_connect("localhost","root","","society");
			$result=mysqli_query($con,"SELECT * FROM `meeting`");
			echo"<table border='1'><tr><th>meeting_id</th><th>meeting reason</th><th>location</th><th>time</th><th>type</th><th>agenda</th></tr>";
			while($row=mysqli_fetch_array($result))
			{
				echo "<tr><td>";		
				echo $row["meeting_id"];
				echo "</td><td>";		
				echo $row["meeting_reason"];
				echo "</td><td>";
				echo $row["meeting_location"];
				echo "</td><td>";
				echo $row["meeting_time"];
				echo "</td><td>";
				echo $row["meeting_type"];
				echo "</td><td>";
				echo $row["agenda"];
				echo "</td></tr>";		
			}
			echo "</table>";
		?>	
	</center>		
	</body>
</html>