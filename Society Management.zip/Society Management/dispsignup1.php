<html>
	<head>
	<body>
		<?php
			$con=mysqli_connect("localhost","root","","society");
			$result=mysqli_query($con,"SELECT * FROM `admin`");
			echo"<table border='1'><tr><th>admin_id</th><th>admin name</th><th>gender</th><th>uname</th><th>pword</th></tr>";
			while($row=mysqli_fetch_array($result))
			{
				echo "<tr><td>";		
				echo $row["admin_id"];
				echo "</td><td>";		
				echo $row["admin_name"];
				echo "</td><td>";
				echo $row["admin_gender"];
				echo "</td><td>";
				echo $row["admin_uname"];
				echo "</td><td>";
				echo $row["admin_pword"];
				echo "</td></tr>";		
			}
			echo "</table>";
		?>			
	</body>
</html>