<html>
	<head>
	<body>
		<?php
			$con=mysqli_connect("localhost","root","","society");
			$result=mysqli_query($con,"SELECT * FROM `member`");
			echo"<table border='1'><tr><th>member_id</th><th> name</th><th>dob</th><th>gender</th><th>uname</th><th>pword</th><th>block number</th><th>parking number</th><th>vehicle number</th></tr>";
			while($row=mysqli_fetch_array($result))
			{
				echo "<tr><td>";		
				echo $row["member_id"];
				echo "</td><td>";		
				echo $row["member_name"];
				echo "</td><td>";
				echo $row["member_dob"];
				echo "</td><td>";
				echo $row["member_gender"];
				echo "</td><td>";
				echo $row["member_uname"];
				echo "</td><td>";
				echo $row["member_pword"];
				echo "</td><td>";
				echo $row["block_number"];
				echo "</td><td>";
				echo $row["parking_number"];
				echo "</td><td>";
				echo $row["vehicle_number"];
				echo "</td></tr>";		
			}
			echo "</table>";
		?>			
	</body>
</html>