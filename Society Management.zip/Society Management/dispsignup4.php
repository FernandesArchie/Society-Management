<html>
	<head>
	<body>
		<?php
			$con=mysqli_connect("localhost","root","","society");
			$result=mysqli_query($con,"SELECT * FROM `employee`");
			echo"<table border='1'><tr><th>employee_id</th><th> name</th><th>dob</th><th>gender</th><th>address</th><th>contact</th><th>contract</th><th>vehicle number</th></tr>";
			while($row=mysqli_fetch_array($result))
			{
				echo "<tr><td>";		
				echo $row["employee_id"];
				echo "</td><td>";		
				echo $row["employee_name"];
				echo "</td><td>";
				echo $row["employee_dob"];
				echo "</td><td>";
				echo $row["employee_gender"];
				echo "</td><td>";
				echo $row["employee_address"];
				echo "</td><td>";
				echo $row["employee_contact"];
				echo "</td><td>";
				echo $row["employee_contact"];
				echo "</td><td>";
				echo $row["vehicle_number"];
				echo "</td></tr>";		
			}
			echo "</table>";
		?>			
	</body>
</html>