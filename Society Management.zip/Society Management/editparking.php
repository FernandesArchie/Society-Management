<?php
    session_start();
    $errmsg_arr = array();
    $errflag = false;
    $vrno = $_POST["textvrn"];
    $id = $_POST["id"];
    $con = new mysqli("localhost", "root", "", "society");
    if($stmt3 = $con->prepare ("SELECT `society_id` FROM `parking` WHERE `parking_number` = ? limit 1")){
        $stmt3->bind_param('s', $vrno);  // Bind "$name" to parameter.
        $stmt3->execute();    // Execute the prepared query.
        $stmt3->store_result();
        $stmt3->bind_result($sno);
        $stmt3->fetch();
    }
    if($vrno != ""){
        if($stmt6 = $con->prepare ("SELECT `parking_number`, `member_id` FROM `parking` WHERE parking_vnumber = ? AND society_id = ? limit 1")){
            $stmt6->bind_param('ss', $vrno, $sno);  // Bind "$name" to parameter.
            $stmt6->execute();    // Execute the prepared query.
            $stmt6->store_result();
            $stmt6->bind_result($vpn, $mid);
            $stmt6->fetch();
        }
        if ($stmt6->num_rows == 1) {
            if($stmt8 = $con->prepare ("SELECT `member_name`, `member_type`, `flat_number` FROM `member` WHERE member_id = ? limit 1")){
                $stmt8->bind_param('s', $mid);  // Bind "$name" to parameter.
                $stmt8->execute();    // Execute the prepared query.
                $stmt8->store_result();
                $stmt8->bind_result($vmn, $vmt, $vfn);
                $stmt8->fetch();
            }
            $errmsg_arr[] = "Vehicle Already registered to:".$vmt." ".$vmn." from Flat no:".$vfn." and has Parking Spot number:".$vpn;
            $errflag=true;
        }
    }
    if(!($errflag)){
        $stmt5 = $con->prepare ("UPDATE `parking` SET `parking_vnumber`= ? WHERE `parking_id` = ?");
        $stmt5 -> bind_param('ss', $vrno, $id);
        $stmt5 -> execute();
        $errmsg_arr[]='Vehicle Registration Number Successfully Updated';
    }
    if($errflag){
         $_SESSION['ERR_ARR']=$errmsg_arr;
        session_write_close();
    }
    else{
        $_SESSION['MG_ARR']=$errmsg_arr;
        session_write_close();
    }
    header("location: admin.php?con=ap");
		  exit();
?>