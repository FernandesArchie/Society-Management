	<?php
	//Start session
	session_start();	
	//Unset the variables stored in session
	unset($_SESSION['SESS_MEMBER_ID']);
	unset($_SESSION['SESS_FIRST_NAME']);
	unset($_SESSION['SESS_LAST_NAME']);
	?>


<html>
	<head>
		<link rel="stylesheet" type="text/css" href="yo.css">
	</head>
	
	<body>
        <center>
        <fieldset class="index" style="height:25%;">
        </fieldset>
            <fieldset class="index" style="height:50%;">
               <fieldset class="indexfield">
	<center><h2 class="loginindex">Login</h2></center>
        
		<form name="loginform" action="login_exec.php" method="post">
          
<table class="tableindex" width="309" border="0" align="center" cellpadding="2" cellspacing="5">
    
  <tr>
    <td colspan="2">
		<!--the code bellow is used to display the message of the input validation-->
		 <?php
			if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
			echo '<ul class="err">';
			foreach($_SESSION['ERRMSG_ARR'] as $msg) {
				echo '<li>',$msg,'</li>'; 
				}
			echo '</ul>';
			unset($_SESSION['ERRMSG_ARR']);
			}
		?>
	</td>
  </tr>
  <tr>
     
    <td width="116"><fieldset  class="index1" align="right">Username</fieldset></td>
    <td width="177"><input name="username" type="text" /></td>
  </tr>
  <tr>
    <td><fieldset class="index1" align="right">Password</fieldset></td>
    <td><input name="password" type="password" /></td>
  </tr>
  <tr>
    <td><fieldset  class="index1" align="right"></fieldset></td>
    <td><input name="" type="submit" value="Login" /></td>
  </tr>
   
</table>     
</form>
                       </fieldset></fieldset>
            </fieldset>
        <fieldset class="index" style="height:17%;">
        </fieldset>
            </center>
	</body>
</html>