<?php
	//Start session
	session_start();
 
	//Include database connection details
	require_once('connection.php');
 
	//Array to store validation errors
	$errmsg_arr = array();
 
	//Validation error flag
	$errflag = false;
 
	//Function to sanitize values received from the form. Prevents SQL injection
	function clean($str) {
		$str = @trim($str);
		if(get_magic_quotes_gpc()) {
			$str = stripslashes($str);
		}
		return mysql_real_escape_string($str);
	}
 
	//Sanitize the POST values
	$username = clean($_POST['username']);
	$password = clean($_POST['password']);
 
	//Input Validations
	if($username == '') {
		$errmsg_arr[] = 'Username missing';
		$errflag = true;
	}
	if($password == '') {
		$errmsg_arr[] = 'Password missing';
		$errflag = true;
	}
 
	//If there are input validations, redirect back to the login form
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();
		header("location: index.php");
		exit();
	}
 
	//Create query
	$qry="SELECT * FROM admin WHERE admin_uname='$username' AND admin_pword='$password'";
	$result=mysql_query($qry);
    $qry1="SELECT * FROM member WHERE member_uname='$username' AND member_pword='$password'";
	$result1=mysql_query($qry1);
 
	//Check whether the query was successful or not
	if($result || $result1) {
		if(mysql_num_rows($result) > 0) {
			//Login Successful
			session_regenerate_id();
			$member = mysql_fetch_assoc($result);
			$_SESSION['SESS_MEMBER_ID'] = $member['admin_id'];
			$_SESSION['SESS_FIRST_NAME'] = $member['admin_name'];
			$_SESSION['SESS_LAST_NAME'] = $member['admin_pword'];
            $_SESSION['SESS_ADMIN']="yes";
			session_write_close();
			header("location: admin.php");
			exit();
        }else if(mysql_num_rows($result1) > 0) {
			//Login Successful
			session_regenerate_id();
			$member = mysql_fetch_assoc($result1);
			$_SESSION['SESS_MEMBER_ID'] = $member['member_id'];
			$_SESSION['SESS_FIRST_NAME'] = $member['member_name'];
			$_SESSION['SESS_LAST_NAME'] = $member['member_pword'];
            $_SESSION['SESS_ADMIN']="no";
			session_write_close();
			header("location: member.php");
			exit();
		}else {
			//Login failed
			$errmsg_arr[] = 'incorrect username or password';
			$errflag = true;
			if($errflag) {
				$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
				session_write_close();
				header("location: index.php");
				exit();
			}
		}
	}else {
		die("Query failed");
	}
?>