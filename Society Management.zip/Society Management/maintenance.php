<html>
	<html>
	<head>
	</head>
	
	<body>
		<?php
			$flat=$_POST["textloc"];
			$reason=$_POST["txtag"];
			$con=mysqli_connect("localhost","root","","society");
			mysqli_query($con,"INSERT INTO `maintenance`(`flat_number`, `reason`) VALUES ('$flat','$reason')");
			mysqli_close($con);
			echo "<h1>Successfully Submitted</h1></center>";
		?>
	</body>
</html>
	