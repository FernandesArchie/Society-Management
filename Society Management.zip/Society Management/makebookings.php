<html>
	<head>
		<link rel="stylesheet" type="text/css" href="yo.css">
	</head>

	<body>
	<form name="bookings" action="bookings.php" method="post">
		<center>
	
		<h2>Request For Bookings</h2>
			<table>
				<tr>
					<td>Type:</td>
					<td><select name="yo">
						<option value="hall">Hall</option>
						<option value="pool">Pool Area</option>
					</select></td>
				</tr>	

			

				<tr>
					<td>Number Of People:</td>
					<td><input type="text" name="txtnop"></td>
				</tr>	

				<tr>
					<td>Time:</td>
					<td><input type="time" name="txtnop"></td>
				</tr>
				<tr>
					<td>Date:</td>
					<td><input type="date" name="dtp" value="DD"></td>
				</tr>

				<tr>
					<td>Reason:</td>
					<td><textarea name="txtag" width="100" height="50"></textarea></td>
				</tr>
				
				<tr>
					<td><input type="submit" value="Register"></td>
					<td><input type="reset" value="Clear"></td>
				</tr>	
			</table>
			
			</center>
	</form>		
	</body>
</html>