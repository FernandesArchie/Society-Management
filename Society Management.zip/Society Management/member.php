<?php
	require_once('auth.php');
    if($_SESSION['SESS_ADMIN']=="yes"){
        header("location: admin.php");
			exit();}
?>

<html>
	<head>
        <link rel="stylesheet" type="text/css" href="yo.css">
    </head>
	<body>
<center>
	<fieldset id="col1">
		<center><img src="yo.png" width="80px" height="80px">
		<h3> Society Management System</h3>
		</center>
	</fieldset>
	<fieldset id="col" >
	<center>
	<table border="0">
	<tr>
	
	<td class="l1" style="width:200"><a href="?con=an">REQUEST BOOKING </a></td>
	<td class="l1" style="width:200"><a href="?con=cm">MAINTAINENCE</a></td>
	
	
        
        <td class="l1" style="width:200"><a href="?con=am">VIEW MEETINGS</a></td>

	
        <td class="l1" style="width:200"><a href="?con=as">VIEW ANNOUNCEMENTS</a></td>
	
	<td class="l1" style="width:200"><a href="logout.php">LOG OUT</a></td>



	</tr>

</table> 
</center>

	</fieldset>
	
	<fieldset id="col2">
<div>
	<?php
		error_reporting(0);
		switch($_REQUEST['con'])
		{
			case 'an':include("bookings.html");
				break;
			case 'cm':include("mainten.html");
				break;
			case 'am':include("dispmeeting.php");
				break;
			case 'as':include("dispannouncement.php");
				break;
		}
	?>

</div>
	</fieldset>
</center>
	
	</body>
</html>