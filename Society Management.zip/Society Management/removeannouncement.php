<?php
    session_start();
    $errmsg_arr = array();
    $errflag = false;
	$id = $_POST["chk"];
	$con = new mysqli("localhost", "root", "", "society");

    if (empty($id)) {
        $errmsg_arr[] = 'Please Select A Society';
        $errflag=true;
    }
     
    if($errflag){
         $_SESSION['ERRMSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    else{
        $n = count($id);
        $stmt1 = $con->prepare ("DELETE FROM `announcement` WHERE `announcement_id` = ?");
        for($i=0;$i<$n;$i++){
            $stmt1 -> bind_param('s', $id[$i]);
            $stmt1 -> execute();
        }
        $errmsg_arr[] = 'Announcement(s) successfully deleted';
        $_SESSION['MSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    header("location: admin.php?con=sra");
	exit();
?>	