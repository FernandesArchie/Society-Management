<?php
    $errmsg_arr = array();
    $errflag = false;
	$con = new mysqli("localhost", "root", "", "society");
    $con1 = new mysqli("localhost", "root", "", "society");
    $con2 = new mysqli("localhost", "root", "", "society");

    if(isset($_POST["edit"])){
        $id = $_POST["edit"];
        if($stmt = $con->prepare ("SELECT `facility_name`, `society_id` FROM `facilities` WHERE `facility_id` = ? limit 1")){
            $stmt -> bind_param('s', $id);
            $stmt->execute();    // Execute the prepared query.
            $stmt -> bind_result($name, $s);
            $stmt -> fetch();
        }
        if($stmt = $con1->prepare ("SELECT `society_name`, `society_locality` FROM `society` WHERE `society_id` = ? limit 1")){
            $stmt -> bind_param('s', $s);
            $stmt->execute();    // Execute the prepared query.
            $stmt -> bind_result($sname, $slocal);
            $stmt -> fetch();
        }
?>
<html>
	<head>
        <link rel="stylesheet" type="text/css" href="yo.css">
        <script>
            function validate(){
                var fname=document.form.fname;
                var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
                var numbers = /^[0-9]+$/;
                if(fname.value == "")
			     {
				    alert("Please enter the facility name\n");
                     fname.focus();
				    return false;
			     }
                 for (var i = 0; i < fname.value.length; i++) {
                    if (iChars.indexOf(fname.value.charAt(i)) != -1) {
                        alert ("Facility Name Cannot Contain special characters");
                        uname.focus();
                        return false;
                    }
                }
                if(fname.value.match(numbers))  
                {  
                    alert("Facility name Should Contain Alphabets");
                    fname.focus();
                    return false;
                }
                if(fname.value.length>30){
                    alert("Facility Name Cannot Contain more than 30 characters");
                    fname.focus();
                    return false;
                }
                if(fname.value == <?php echo "'".$name."'"; ?>)
			     {
				    alert("No Changes Detected\n");
                     fname.focus();
				    return false;
			     }
                return true;
            }
        </script>
    </head>
    <body>
<?php
        echo"<form name=\"form\" action=\"alterfacility.php\" method=\"post\" >";
        echo "<center>";
        echo "<h2>Edit ".$name." from ".$sname.": ".$slocal."</h2>";
        echo "<input type='hidden' name='id' value='".$id."'>";
        echo "<table>";
        echo "<tr><td>Name:</td><td><input type=\"text\" name=\"fname\" value=\"".$name."\"></td></tr>";
        echo "<tr><td colspan='2'><center><input type=\"submit\" value=\"Submit\" onclick=\"return validate()\"></center></td></tr></table>";
    }
    else{
        $id = $_POST["chk"];
        $n = count($id);
        $stmt = $con->prepare ("DELETE FROM `facilities` WHERE `facility_id` = ?");
        for($i=0;$i<$n;$i++){
            $stmt -> bind_param('s', $id[$i]);
            $stmt -> execute();
        }
        if($n == 1)
            $errmsg_arr[] = 'Facility Successfully Removed';
        else
            $errmsg_arr[] = 'Facilities Successfully Removed';
        $_SESSION['MG_ARR'] = $errmsg_arr;
        session_write_close();
        header("location: admin.php?con=erf");
	    exit();
    }
?>
    </body>
</html>