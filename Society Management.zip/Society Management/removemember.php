<?php
    $errmsg_arr = array();
    $errflag = false;
	$con = new mysqli("localhost", "root", "", "society");
    $con1 = new mysqli("localhost", "root", "", "society");
    $con2 = new mysqli("localhost", "root", "", "society");

    if(isset($_POST["edit"])){
        $id = $_POST["edit"];
        if($stmt = $con->prepare ("SELECT `member_name`, `member_gender`, `member_uname`, `flat_number`, `member_type`, `society_id` FROM `member` WHERE `member_id` = ?")){
            $stmt -> bind_param('s', $id);
            $stmt->execute();    // Execute the prepared query.
            $stmt -> bind_result($name, $gender, $uname, $flat, $type, $sid);
            $stmt -> fetch();
        }
?>
<html>
	<head>
        <link rel="stylesheet" type="text/css" href="yo.css">
        <script>
            function validate(){
                var name = document.form.text0;
                var gender = document.form.sel2;
                var pass = document.form.textp;
                var cpass = document.form.textr;
                var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?_";
                var numbers = /^[0-9]+$/;
                var alphabets = /^[A-Za-z ]+$/;
                if (name.value == "" && pass.value == "" && cpass.value == ""){
				    alert("Please enter the details you want to change\n");
                    name.focus();
				    return false;
			     }
                for (var i = 0; i < name.value.length; i++) {
                    if (iChars.indexOf(name.value.charAt(i)) != -1) {
                        alert ("Name Cannot Contain special characters and \"_\"");
                        name.focus();
                        return false;
                    }
                }
                if(!(name.value.match(alphabets)))  {  
                    alert("Name Should not contain Numbers");
                    name.focus();
                    return false;
                }
                if(name.value.length>30){
                    alert("Name Cannot Contain more than 30 characters");
                    name.focus();
                    return false;
                }
                if (pass.value.length>30){
                    alert("Password cannot Contain more than 30 characters");
                    pass.focus();
                    return false;
                }
                if(pass.value != ""){
                     if (pass.value.length<6){
                        alert("Password cannot Contain less than 6 characters");
                        pass.focus();
                        return false;
                    }
                }
                if (pass.value != cpass.value){
                    alert("Passwords Dont Match");
                    pass.focus();
                    cpass.focus();
                    return false;
                }
                if(pass.value != ""){
                    var exe = confirm("You are about to change this user's password.\nAre you sure you want to continue?");
                    return exe;
                }
                return true;
            }
        </script>
    </head>
    <body>
<?php
        echo"<form name=\"form\" action=\"altermember.php\" method=\"post\" >";
        echo "<center>";
        echo "<h2>Edit ".$uname."'s Details</h2>";
        echo "<input type='hidden' name='mid' value='".$id."'>";
        echo "<table>";
        echo "<tr><td>Name:</td><td><input type=\"text\" name=\"text0\" value=\"".$name."\"></td></tr>";
        echo "<tr><td>Gender:</td><td><select name=\"sel2\"><option value=\"Male\"";
        if($gender == 'Male')
            echo "selected";
        echo ">Male</option><option value=\"Female\"";
        if($gender == 'Female')
            echo "selected";
        echo ">Female</option></select></td></tr>";
        echo "<tr><th colspan='2'>Reset Password</th></tr>";
        echo "<tr><td>Password:</td><td><input type=\"password\" name=\"textp\"></td></tr>";
        echo "<tr><td>Confirm Password</td><td><input type=\"password\" name=\"textr\"></td></tr>";
        echo "<tr><td colspan='2'><center><input type=\"submit\" value=\"Submit\" onclick=\"return validate()\"></center></td></tr></table>";
    }
    else{
        $id = $_POST["chk"];
        $n = count($id);
        $stmt = $con->prepare ("SELECT `flat_number` FROM `member` WHERE `member_id` = ?"); //check flat
        $stmt0 = $con1->prepare ("SELECT `member_id` FROM `member` WHERE `flat_number` = ? AND `member_type` = 'Tenant'"); //get tenent id
        $stmt1 = $con2->prepare ("DELETE FROM `announcement` WHERE `member_id` = ?"); //delete announcements
        $stmt2 = $con2->prepare ("DELETE FROM `bookings` WHERE `member_id` = ?"); //delete bookings
        $stmt3 = $con2->prepare ("DELETE FROM `grievance` WHERE `member_id` = ?"); //delete Grievances
        $stmt4 = $con2->prepare ("DELETE FROM `member` WHERE `member_id` = ?"); //Delete member / tenent
        $stmt5 = $con2->prepare ("DELETE FROM `parking` WHERE `member_id` = ?"); //Delete parking
        for($i=0;$i<$n;$i++){
            $stmt -> bind_param('s', $id[$i]);
            $stmt -> execute();
            $stmt -> bind_result($fno);
            $stmt -> fetch();
            
            $stmt1 -> bind_param('s', $id[$i]);
            $stmt1 -> execute();
                
            $stmt2 -> bind_param('s', $id[$i]);
            $stmt2 -> execute();
            
            $stmt3 -> bind_param('s', $id[$i]);
            $stmt3 -> execute();
                
            $stmt4 -> bind_param('s', $id[$i]);
            $stmt4 -> execute();
                
            $stmt5 -> bind_param('s', $id[$i]);
            $stmt5 -> execute();
                        
            $stmt0 -> bind_param('s', $fno);
            $stmt0 -> execute();
            $stmt0 -> bind_result($idt);
            $stmt0 -> fetch();
            
            if ($idt != NULL) {
                $stmt1 -> bind_param('s', $idt);
                $stmt1 -> execute();
                
                $stmt2 -> bind_param('s', $idt);
                $stmt2 -> execute();
                
                $stmt3 -> bind_param('s', $idt);
                $stmt3 -> execute();
                
                $stmt4 -> bind_param('s', $idt);
                $stmt4 -> execute();
                
                $stmt5 -> bind_param('s', $idt);
                $stmt5 -> execute();
                
            }
        }
        $errmsg_arr[] = 'Members(s) successfully deleted';
        $_SESSION['MG_ARR'] = $errmsg_arr;
        session_write_close();
        header("location: admin.php?con=erm");
	    exit();
    }
?>
    </body>