<?php
    $errmsg_arr = array();
    $errflag = false;
	$con = new mysqli("localhost", "root", "", "society");
    $con1 = new mysqli("localhost", "root", "", "society");
    $con2 = new mysqli("localhost", "root", "", "society");

    if(isset($_POST["edit"])){
        $id = $_POST["edit"];
        if($stmt = $con->prepare ("SELECT `society_name`, `society_locality` FROM `society` WHERE `society_id` = ?")){
            $stmt -> bind_param('s', $id);
            $stmt->execute();    // Execute the prepared query.
            $stmt -> bind_result($name, $address);
            $stmt -> fetch();
        }
?>
<html>
	<head>
        <link rel="stylesheet" type="text/css" href="yo.css">
        <script>
            function validate(){
                var a=document.signup.text1;
                var b=document.signup.textloc;
                var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
                var iChars2 = "!@#$%^&*()+=[]\';{}|\"<>?";
                var numbers = /^[0-9]+$/;
                if(a.value == "")
			     {
				    alert("Please enter the society name\n");
                     a.focus();
				    return false;
			     }
                if(b.value == "")
			     {
				    alert("Please enter the address\n");
                     b.focus();
				    return false;
			     }
                for (var i = 0; i < a.value.length; i++) {
                    if (iChars.indexOf(a.value.charAt(i)) != -1) {
                        alert ("Society Name Cannot Contain these characters:\n!@#$%^&*()+=-[]\\\';,./{}|\":<>?");
                        a.focus();
                        return false;
                    }
                }
                 for (var i = 0; i < b.value.length; i++) {
                    if (iChars2.indexOf(b.value.charAt(i)) != -1) {
                        alert ("Society Address Cannot Contain these characters:\n!@#$%^&*()+=[]\';{}|\"<>?");
                        b.focus();
                        return false;
                    }
                }  
                if(a.value.match(numbers))  
                {  
                    alert("Society Name Should Contain Alphabets");
                    a.focus();
                    return false;
                }
                if(b.value.match(numbers))  
                {  
                    alert("Society Address Should Contain Alphabets");
                    b.focus();
                    return false;
                }
                if(a.value.length<3){
                    alert("Society Name Cannot Contain less than 3 characters");
                    a.focus();
                    return false;
                }
                if(b.value.length<5){
                    alert("Society Address Cannot Contain more than 3 characters");
                    b.focus();
                    return false;
                }
                if(a.value.length>30){
                    alert("Society Name Cannot Contain more than 30 characters");
                    a.focus();
                    return false;
                }
                if(b.value.length>100){
                    alert("Society Address Cannot Contain more than 100 characters");
                    b.focus();
                    return false;
                }
                return true;
            }
        </script>
    </head>
    <body>
<?php
        echo"<form name=\"form\" action=\"altersociety.php\" method=\"post\" >";
        echo "<center>";
        echo "<h2>Edit ".$name."'s Details</h2>";
        echo "<input type='hidden' name='id' value='".$id."'>";
        echo "<table>";
        echo "<tr><td>Name:</td><td><input type=\"text\" name=\"text1\" value=\"".$name."\"></td></tr>";
        echo "<tr><td>Address:</td><td><textarea rows=\"4\" cols=\"50\" name=\"textloc\">".$address."</textarea></td></tr>";
        echo "<tr><td colspan='2'><center><input type=\"submit\" value=\"Submit\" onclick=\"return validate()\"></center></td></tr></table>";
    }
    else{
        $id = $_POST["chk"];
        $n = count($id);
        $stmt = $con->prepare ("SELECT `member_id` FROM `member` WHERE `society_id` = ?"); //get member ids
        $stmt0 = $con1->prepare ("DELETE FROM `announcement` WHERE `member_id` = ?"); //delete member announcements
        $stmt1 = $con2->prepare ("DELETE FROM `announcement` WHERE `society_id` = ?"); //delete announcements
        $stmt2 = $con1->prepare ("DELETE FROM `bookings` WHERE `member_id` = ?"); //delete bookings
        $stmt3 = $con2->prepare ("DELETE FROM `conadmin` WHERE `society_id` = ?"); //delete unapproved members
        $stmt4 = $con2->prepare ("DELETE FROM `contact` WHERE `society_id` = ?"); //Delete contacts
        $stmt5 = $con2->prepare ("DELETE FROM `facilities` WHERE `society_id` = ?"); //Delete facilities
        $stmt6 = $con1->prepare ("DELETE FROM `grievance` WHERE `member_id` = ?"); //Delete member grievances
        $stmt7 = $con2->prepare ("DELETE FROM `meeting` WHERE `society_id` = ?"); //Delete meetings
        $stmt8 = $con2->prepare ("DELETE FROM `parking` WHERE `society_id` = ?"); //Delete parking
        $stmt9 = $con2->prepare ("DELETE FROM `member` WHERE `society_id` = ?"); //Delete members
        $stmt10 = $con2->prepare ("DELETE FROM `society` WHERE `society_id` = ?"); //Delete society
        for($i=0;$i<$n;$i++){
            $stmt -> bind_param('s', $id[$i]);
            $stmt -> execute();
            $stmt -> bind_result($mid);
            while($stmt -> fetch()){
                $stmt0 -> bind_param('s', $mid);
                $stmt0 -> execute();
                
                $stmt2 -> bind_param('s', $mid);
                $stmt2 -> execute();
                
                $stmt6 -> bind_param('s', $mid);
                $stmt6 -> execute();
            }
            
            $stmt1 -> bind_param('s', $id[$i]);
            $stmt1 -> execute();
                
            $stmt3 -> bind_param('s', $id[$i]);
            $stmt3 -> execute();
            
            $stmt4 -> bind_param('s', $id[$i]);
            $stmt4 -> execute();
                
            $stmt5 -> bind_param('s', $id[$i]);
            $stmt5 -> execute();
                
            $stmt7 -> bind_param('s', $id[$i]);
            $stmt7 -> execute();
            
            $stmt8 -> bind_param('s', $id[$i]);
            $stmt8 -> execute();
            
            $stmt9 -> bind_param('s', $id[$i]);
            $stmt9 -> execute();
            
            $stmt10 -> bind_param('s', $id[$i]);
            $stmt10 -> execute();
        }
        if($n == 1)
            $errmsg_arr[] = 'Society Successfully Removed';
        else
            $errmsg_arr[] = 'Societies Successfully Removed';
        $_SESSION['MG_ARR'] = $errmsg_arr;
        session_write_close();
        header("location: admin.php?con=ers");
	    exit();
    }
?>
    </body>
</html>