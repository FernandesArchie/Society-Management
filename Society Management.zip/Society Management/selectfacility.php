<?php unset($_SESSION['NM_ARR']); ?>
<html>
	<head>
        <link rel="stylesheet" type="text/css" href="yo.css">
        <script>
            function toggle(source) {
                checkboxes = document.getElementsByName('chk[]');
                for(var i=0, n=checkboxes.length;i<n;i++) {
                    checkboxes[i].checked = source.checked;
                }
            }
            function csociety(){
                var seld = document.announcement.society.value;
                window.location.href ='admin.php?con=erf&soc=' + seld;
            }
            function validate(){
                checkboxes = document.getElementsByName('chk[]');
                var test = true;
                for(var i=0, n=checkboxes.length;i<n;i++) {
                    if(checkboxes[i].checked)
                        test = false;
                }
                if(test){
                    alert("Please Select at least one facility to delete");
                    return false;
                }
            }
        </script>
	</head>
    <body>
<?php
    $NM_ARR = array();
    $errflag = false;
    $con = new mysqli("localhost", "root", "", "society");
    if(!(isset($_GET['soc']))) {
        if($stmt = $con->prepare ("SELECT `facility_id`, `facility_name`, `society_id` FROM `facilities` WHERE 1")){
            $stmt->execute();    // Execute the prepared query.
            $stmt->store_result();
        }
        if ($stmt->num_rows == 0) {
            $NM_ARR[] = 'There are no registered facilities';
            $errflag=true;
        }
    }
    else{
        $sid = $_GET['soc'];
        if($sid == '-1'){
            if($stmt = $con->prepare ("SELECT `facility_id`, `facility_name`, `society_id` FROM `facilities` WHERE 1")){
                $stmt->execute();    // Execute the prepared query.
                $stmt->store_result();
            }
            if ($stmt->num_rows == 0) {
                $NM_ARR[] = 'There are no registered members';
                $errflag=true;
            }
        }
        else{
            if($stmt = $con->prepare ("SELECT `facility_id`, `facility_name`, `society_id` FROM `facilities` WHERE `society_id` = ?")){
                $stmt->bind_param('s', $sid);
                $stmt->execute();    // Execute the prepared query.
                $stmt->store_result();
            }
            if ($stmt->num_rows == 0) {
                $NM_ARR[] = 'There are no registered facilities in the selected Society';
                $errflag=true;
            }
        }
    }
    if($errflag){
         $_SESSION['NM_ARR']=$NM_ARR;
        session_write_close();
    }
?>
	<form name="announcement" action="admin.php?con=rf" method="post" >
		<center>
        <div>
		<h2>Edit / Remove Facilities</h2>
			<table border = '1'>                    
                <tr><th><input type="checkbox" onClick="toggle(this)" /></th><th>Name</th>
                    <th>Society:<select name = "society" onchange="csociety();">
                        <?php
                            $sid = -1;
                            if(isset($_GET['soc']))
                                $sid = $_GET['soc'];
                            echo"<option value = '-1'";
                            echo">---</option>";
                            echo"<option value = '0'";
                            if($sid == 0)
                                echo"selected";
                            echo">All Societies</option>";
                            $con2=mysqli_connect("localhost","root","","society");
			                $result=mysqli_query($con2,"SELECT * FROM `society`");
			                while($row=mysqli_fetch_array($result))
			                {
				                echo "<option value='";		
				                echo $row["society_id"]."'";
                                if($sid==$row["society_id"])
                                    echo"selected";
				                echo ">";		
				                echo $row["society_name"];
				                echo ": ";
				                echo $row["society_locality"];
				                echo "</option>";		
			                }
                            mysqli_close($con2);
		              ?>
                    </select></th><th>Edit</th>
                </tr>
                <?php
                    if( isset($_SESSION['MG_ARR']) && is_array($_SESSION['MG_ARR']) && count($_SESSION['MG_ARR']) >0 ) {
			             echo "<tr>";
                         echo'<td colspan="4">';
                         echo '<ul class="msg">';
			             foreach($_SESSION['MG_ARR'] as $msg) {
				            echo '<li>',$msg,'</li>';
				         }
                        unset($_SESSION['MG_ARR']);
			             echo '</ul>';
                         echo'</td>';
                         echo'</tr>';
			         }
			         if( isset($_SESSION['NM_ARR']) && is_array($_SESSION['NM_ARR']) && count($_SESSION['NM_ARR']) >0 ) {
			             echo "<tr>";
                         echo'<td colspan="4">';
                         echo '<ul class="err">';
                         
			             foreach($_SESSION['NM_ARR'] as $msg) {
				              echo '<li>',$msg,'</li>';
				         }
			             echo '</ul>';
                         unset($_SESSION['NM_ARR']);
                         echo'</td></tr>';
			         }
                ?>
                <?php
                $stmt->execute();
                $stmt->bind_result($id, $name, $sid);
                while ($stmt->fetch()) {
                    echo "<tr><td>";
                    echo "<input type = 'checkbox' name = 'chk[]' value = '".$id."'>";
                    echo "</td><td>";
                    echo $name;
                    if($sid == 0){
                        echo "</td><td>";
                        echo "All Societies";
                    }
                    else{
                        $con2=mysqli_connect("localhost","root","","society");
			            $result=mysqli_query($con2,"SELECT * FROM `society` where society_id = ".$sid);
			            $row=mysqli_fetch_array($result);
                        echo "</td><td>";				
                        echo $row["society_name"];
                        echo ": ";
                        echo $row["society_locality"];		
			            mysqli_close($con2);
                    }
                    echo "</td><td>";
                    echo "<button name='edit' type='submit' value='".$id."'>Edit</button>";
                    echo "</td></tr>";
                }
            ?>
				<tr>
                    <td colspan="4"><center><input type="submit" value="Delete" onclick="return validate()"><input type="reset" value="Clear"></center></td>
				</tr>	
			</table>
            </div>
        </center>
	</form>	
	</body>
</html>