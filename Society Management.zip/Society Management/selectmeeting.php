<?php unset($_SESSION['ERRMSG_ARR']); ?>
<html>
	<head>
        <link rel="stylesheet" type="text/css" href="yo.css">
        <script>
            function toggle(source) {
                checkboxes = document.getElementsByName('chk[]');
                for(var i=0, n=checkboxes.length;i<n;i++) {
                    checkboxes[i].checked = source.checked;
                }
            }
            function csociety(){
                var seld = document.announcement.society.value;
                window.location.href ='admin.php?con=vrm&soc=' + seld;
            }
            function validate(){
                checkboxes = document.getElementsByName('chk[]');
                var test = true;
                for(var i=0, n=checkboxes.length;i<n;i++) {
                    if(checkboxes[i].checked)
                        test = false;
                }
                if(test){
                    alert("Please Select at least one meeting to delete");
                    return false;
                }
            }
        </script>
	</head>
    <body>
<?php
    $errmsg_arr = array();
    $errflag = false;
    
    $con = new mysqli("localhost", "root", "", "society");
    if(!(isset($_GET['soc']))) {
        if($stmt = $con->prepare ("SELECT * FROM `meeting` WHERE 1")){
            $stmt->execute();    // Execute the prepared query.
            $stmt->store_result();
        }
        if ($stmt->num_rows == 0) {
            $errmsg_arr[] = 'There are no scheduled meetings';
            $errflag=true;
        }
    }
    else{
        $sid = $_GET['soc'];
        if($sid == '-1'){
            if($stmt = $con->prepare ("SELECT * FROM `meeting` WHERE 1")){
                $stmt->execute();    // Execute the prepared query.
                $stmt->store_result();
            }
            if ($stmt->num_rows == 0) {
                $errmsg_arr[] = 'There are no scheduled meetings';
                $errflag=true;
            }
        }
        else{
            if($stmt = $con->prepare ("SELECT * FROM `meeting` WHERE society_id = ?")){
                $stmt->bind_param('s', $sid);
                $stmt->execute();    // Execute the prepared query.
                $stmt->store_result();
            }
            if ($stmt->num_rows == 0) {
                $errmsg_arr[] = 'There are no meetings scheduled for the selected Society';
                $errflag=true;
            }
        }
    }
    if($errflag){
         $_SESSION['ERRMSG_ARR']=$errmsg_arr;
        session_write_close();
    }
?>
	<form name="announcement" action="removemeeting.php" method="post" >
		<center>
        <div>
		<h2>View / Delete Meetings</h2>
			<table border = '1'>                    
                <tr><th><input type="checkbox" onClick="toggle(this)" /></th><th>Reason</th><th>Location</th><th>Date</th><th>Type</th><th>Agenda</th>
                    <th>Society:<select name = "society" onchange="csociety();">
                        <?php
                            $sid = -1;
                            if(isset($_GET['soc']))
                                $sid = $_GET['soc'];
                            echo"<option value = '-1'";
                            echo">---</option>";
                            echo"<option value = '0'";
                            if($sid == 0)
                                echo"selected";
                            echo">All Societies</option>";
                            $con1=mysqli_connect("localhost","root","","society");
			                $result=mysqli_query($con1,"SELECT * FROM `society`");
			                while($row=mysqli_fetch_array($result))
			                {
				                echo "<option value='";		
				                echo $row["society_id"]."'";
                                if($sid==$row["society_id"])
                                    echo"selected";
				                echo ">";		
				                echo $row["society_name"];
				                echo ": ";
				                echo $row["society_locality"];
				                echo "</option>";		
			                }
                            mysqli_close($con1);
		              ?>
                    </select></th>
                </tr>
                <?php
			         if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
			             echo "<tr>";
                         echo'<td colspan="7">';
                         echo '<ul class="err">';
			             foreach($_SESSION['ERRMSG_ARR'] as $msg) {
				              echo '<li>',$msg,'</li>';
				         }
			             echo '</ul>';
                         echo'</td>';
                         echo'</tr>';
			         }
                     if( isset($_SESSION['MSG_ARR']) && is_array($_SESSION['MSG_ARR']) && count($_SESSION['MSG_ARR']) >0 ) {
			             echo "<tr>";
                         echo'<td colspan="7">';
                         echo '<ul class="msg">';
			             foreach($_SESSION['MSG_ARR'] as $msg) {
				            echo '<li>',$msg,'</li>';
				         }
			             echo '</ul>';
			             unset($_SESSION['MSG_ARR']);
                         echo'</td>';
                         echo'</tr>';
			         }
		    ?>
            <?php
                $stmt->execute();
                $stmt->bind_result($id, $reason, $location, $date, $time, $type, $agenda, $sid);
                while ($stmt->fetch()) {
                    echo "<tr><td>";
                    echo "<input type = 'checkbox' name = 'chk[]' value = '".$id."'>";
                    echo "</td><td>";
                    echo $reason;
                    echo "</td><td>";
                    echo $location;
                    echo "</td><td>";
                    $dttime  = date("F j, Y, g:i a", strtotime($date." ".$time));
                    echo $dttime;
                    echo "</td><td>";
                    echo $type;
                    echo "</td><td>";
                    echo $agenda;
                    if($sid == 0){
                        echo "</td><td>";
                        echo "All Societies";
                        echo "</td></tr>";
                    }
                    else{
                        $con1=mysqli_connect("localhost","root","","society");
			            $result=mysqli_query($con1,"SELECT * FROM `society` where society_id = ".$sid);
			            $row=mysqli_fetch_array($result);
                        echo "</td><td>";				
                        echo $row["society_name"];
                        echo ": ";
                        echo $row["society_locality"];
                        echo "</td></tr>";		
			            mysqli_close($con1);
                    }
                }
            ?>
				<tr>
					<td></td>
					<td><input type="submit" value="Delete" onclick="return validate()"><input type="reset" value="Clear"></td>
				</tr>	
			</table>
            </div>
        </center>
	</form>	
	</body>
</html>