<html>
	<html>
	<head>
	</head>
	
	<body>
		<?php
			$name=$_POST["text"];
			$dob=$_POST["text1"];
			$gender=$_POST["sel2"];
			$address=$_POST["textvrn"];
			$contact=$_POST["textloc"];
			$contract=$_POST["textps"];
			$vehicle=$_POST["textvrn"];
			$con=mysqli_connect("localhost","root","","society");
			mysqli_query($con,"INSERT INTO `employee`(`employee_name`, `employee_dob`, `employee_gender`, `employee_address`, `employee_contact`, `employee_conrtact`, `vehicle_number`) VALUES ('$name','$dob','$gender','$address','$contact','$contract','$vehicle')");
			mysqli_close($con);
			echo "<h1>Successfully Submitted</h1></center>";
		?>
	</body>
</html>
	