<html>
	<head>
		<link rel="stylesheet" type="text/css" href="yo.css">
        <script>
            function validate()
            {
                var name=document.signup1.text1;
                var uname=document.signup1.textuname;
                var pass=document.signup1.textpass;
                var cpass=document.signup1.textcpass;
                var iChars = "!@#$%^&*()+=-[]\\\';,./{}|\":<>?";
                var numbers = /^[0-9]+$/;
                var alphabets = /^[A-Za-z ]+$/;
                if(name.value == "")
			     {
				    alert("Please enter your name\n");
                     name.focus();
				    return false;
			     }
                if(uname.value == "")
			     {
				    alert("Please enter the user name\n");
                     uname.focus();
				    return false;
			     }
                if(pass.value == "")
			     {
				    alert("Please enter the password\n");
                     pass.focus();
				    return false;
			     }
                if(cpass.value == "")
			     {
				    alert("Please Confirm your password\n");
                     cpass.focus();
				    return false;
			     }
                if(uname.value.match(" ")){
                    alert("User Name Should not contain spaces");
                    uname.focus();
                    return false;
                }
                for (var i = 0; i < name.value.length; i++) {
                    if (iChars.indexOf(name.value.charAt(i)) != -1) {
                        alert ("Name Cannot Contain these characters:\n!@#$%^&*()+=-[]\\\';,./{}|\":<>?");
                        name.focus();
                        return false;
                    }
                }
                 for (var i = 0; i < uname.value.length; i++) {
                    if (iChars.indexOf(uname.value.charAt(i)) != -1) {
                        alert ("User Name Cannot Contain these characters:\n!@#$%^&*()+=-[]\\\';,./{}|\":<>?");
                        uname.focus();
                        return false;
                    }
                }  
                if(!(name.value.match(alphabets)))  
                {  
                    alert("Name Should not contain Numbers");
                    name.focus();
                    return false;
                }
                if(uname.value.match(numbers))  
                {  
                    alert("User Name Should Contain Alphabets");
                    uname.focus();
                    return false;
                }
                if(name.value.length>30){
                    alert("Name Cannot Contain more than 30 characters");
                    name.focus();
                    return false;
                }
                if(uname.value.length>20){
                    alert("User Name Cannot Contain more than 15 characters");
                    uname.focus();
                    return false;
                }
                if(pass.value.length>30){
                    alert("Password cannot Contain more than 30 characters");
                    pass.focus();
                    return false;
                }
                if(pass.value.length<6){
                    alert("Password cannot Contain less than 6 characters");
                    pass.focus();
                    return false;
                }
                if(pass.value!=cpass.value){
                    alert("Passwords Dont Match");
                    pass.focus();
                    cpass.focus();
                    return false;
                }
                return true;
            }
        </script>
	</head>

	<body>
	<form name="signup1" action="submitadmin.php" method="post">
	<center>
		<h2>Administrator Sign Up </h2>
			<table>
                <tr>
                    <td colspan="2">
                        <?php
                            session_start();
			                 if( isset($_SESSION['ERRMSG_ARR']) && is_array($_SESSION['ERRMSG_ARR']) && count($_SESSION['ERRMSG_ARR']) >0 ) {
			                     echo '<ul class="err">';
			                     foreach($_SESSION['ERRMSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['ERRMSG_ARR']);
			                 }
                            if( isset($_SESSION['MSG_ARR']) && is_array($_SESSION['MSG_ARR']) && count($_SESSION['MSG_ARR']) >0 ) {
			                     echo '<ul class="msg">';
			                     foreach($_SESSION['MSG_ARR'] as $msg) {
				                    echo '<li>',$msg,'</li>';
				                }
			                     echo '</ul>';
			                     unset($_SESSION['MSG_ARR']);
			                 }
		                  ?>
                    </td>
                </tr>
				<tr>
				<tr>
					<td>Name:</td>
					<td><input type="text" name="text1"></td>
				</tr>	

				<tr>
					<td>Gender:</td>
					<td><select name="sel2">
						<option value="Male">Male</option>
						<option value="Female">Female</option>
					     </select></td>
				</tr>	

				<tr>
					<td>User Name:</td>
					<td><input type="text" name="textuname"></td>
				</tr>

				<tr>
					<td>Password:</td>
					<td><input type="password" name="textpass"></td>
				</tr>

				<tr>
					<td>Confirm Password:</td>
					<td><input type="password" name="textcpass"></td>
				</tr>
				
				<tr>
					<td></td>
					<td><input type="submit" value="Sign Up" onClick="return validate()"><input type="reset" value="Clear"></td>
				</tr>	
			</table>
	</center>
	</form>				
	</body>
</html>