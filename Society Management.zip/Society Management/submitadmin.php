<?php
    session_start();
    $errmsg_arr = array();
    $errflag = false;
	$name = $_POST["text1"];
	$gender = $_POST["sel2"];
    $uname = $_POST["textuname"];
    $pass = $_POST["textpass"];
    $con = new mysqli("localhost", "root", "","society");
    if($stmt = $con->prepare ("SELECT `admin_uname` FROM `admin` WHERE admin_uname = ? limit 1")){
        $stmt->bind_param('s', $uname);  // Bind "$name" to parameter.
        $stmt->execute();    // Execute the prepared query.
        $stmt->store_result();
    }
    if($stmt2 = $con->prepare ("SELECT `member_uname` FROM `member` WHERE member_uname = ? limit 1")){
        $stmt2->bind_param('s', $uname);  // Bind "$name" to parameter.
        $stmt2->execute();    // Execute the prepared query.
        $stmt2->store_result();
    }
    if($stmt1 = $con->prepare ("SELECT `admin_uname` FROM `conadmin` WHERE admin_uname = ? limit 1")){
        $stmt1->bind_param('s', $uname);  // Bind "$name" to parameter.
        $stmt1->execute();    // Execute the prepared query.
        $stmt1->store_result();
    }
    if ($stmt->num_rows == 1) {
        $errmsg_arr[] = 'User Name Already Exists';
        $errflag=true;
    }
    else if ($stmt2->num_rows == 1) {
        $errmsg_arr[] = 'User Name Already Exists';
        $errflag=true;
    }
    else if ($stmt1->num_rows == 1) {
        $errmsg_arr[] = 'User Name submitted for approval by another user. please try a different user name.';
        $errflag=true;
    }
    else{
        $stmt = $con->prepare ("INSERT INTO `conadmin`(`admin_name`, `admin_gender`, `admin_uname`, `admin_pword`) VALUES (?, ?, ?, ?)");
        $stmt -> bind_param('ssss', $name, $gender, $uname, $pass);
        $stmt -> execute();
        $errmsg_arr[] = 'Successfully Submitted For Approval';
    }
    if($errflag){
         $_SESSION['ERRMSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    else{
        $_SESSION['MSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    header("location: signupadmin.php");
	exit();
?>