<?php
    session_start();
    $errmsg_arr = array();
    $errflag = false;
	$title = $_POST["title"];
	$content = $_POST["content"];
    $society = $_POST["society"];
    $uname = $_POST["uname"];
    $date = date("F j, Y, g:i a"); 
    $time = time('h:m');
    $con = new mysqli("localhost", "root", "", "society");
    if($society == "all")
        $sno = 0;
    else{
        if($stmt0 = $con->prepare ("SELECT `society_id` FROM `society` WHERE society_name = ? limit 1")){
            $stmt0->bind_param('s', $society);  // Bind "$name" to parameter.
            $stmt0->execute();    // Execute the prepared query.
            $stmt0->store_result();
            $stmt0->bind_result($sno);
            $stmt0->fetch();
        }
    }
    if($uname == "")
        $uno = 0;
    else{
        if($stmt = $con->prepare ("SELECT `member_id` FROM `member` WHERE member_uname = ? AND society_id = ? limit 1")){
            $stmt->bind_param('ss', $uname, $sno);  // Bind "$name" to parameter.
            $stmt->execute();    // Execute the prepared query.
            $stmt->store_result();
            $stmt->bind_result($uno);
            $stmt->fetch();
        }
        if ($stmt->num_rows != 1) {
            $errmsg_arr[] = 'Member user name Does not belong to the selected society';
            $errflag=true;
        }
    }
     
    if($errflag){
         $_SESSION['ERRMSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    else{
        $stmt1 = $con->prepare ("INSERT INTO `announcement`(`announcement_title`, `announcement_content`, `announcement_date`, `member_id`, `society_id`) VALUES (?, ?, ?, ?, ?)");
        $stmt1 -> bind_param('sssss', $title, $content, $date, $uno, $sno);
        $stmt1 -> execute();
        $errmsg_arr[] = 'Announcement Successfully Submitted';
        $_SESSION['MSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    header("location: admin.php?con=aa");
	exit();
?>