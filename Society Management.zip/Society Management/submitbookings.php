<html>
	<html>
	<head>
	</head>
	
	<body>
		<?php
			$type=$_POST["yo"];
			$date=$_POST["Day"]."-".$_POST["Month"]."-".$_POST["Year"];
			$reason=$_POST["txtag"];
			$con=mysqli_connect("localhost","root","","society");
			mysqli_query($con,"INSERT INTO `bookings`(`booking_type`, `booking_date`, `booking_reason`) VALUES ('$type','$date','$reason')");
			mysqli_close($con);
			echo "<h1>Successfully Submitted</h1></center>";
		?>
	</body>
</html>
			