<?php
    session_start();
    $errmsg_arr = array();
    $errflag = false;
    $x=false;
	$society = $_POST["selsoc"];
	$name = $_POST["textomg"];
    $gender = $_POST["sel2"];
    $address = $_POST["textadd"];
    $contactn = $_POST["textcon"];
    $contactn2 = $_POST["textcon2"];
    $email = $_POST["texte"];
    $category = $_POST["selc"];
    $categoryn = $_POST["textc"];
    $con = new mysqli("localhost", "root", "", "society");
    if($society == "all")
        $sno = 0;
    else{
        if($stmt0 = $con->prepare ("SELECT `society_id` FROM `society` WHERE society_name = ? limit 1")){
            $stmt0->bind_param('s', $society);  // Bind "$name" to parameter.
            $stmt0->execute();    // Execute the prepared query.
            $stmt0->store_result();
            $stmt0->bind_result($sno);
            $stmt0->fetch();
        }
    }
    
    if($stmt2 = $con->prepare ("SELECT `category_id` FROM `category` WHERE category_name = ? AND category_type = 'contact' limit 1"))
        $x=true;
    if($category == "" && $x){
        $stmt = $con->prepare ("INSERT INTO `category`(`category_name`, `category_type`) VALUES (?, 'contact')");
        $stmt -> bind_param('s', $categoryn);
        $stmt -> execute();
        $stmt2->bind_param('s', $categoryn);  // Bind "$name" to parameter.
    }
    else if($x)
        $stmt2->bind_param('s', $category);  // Bind "$name" to parameter.
    $stmt2->execute();    // Execute the prepared query.
    $stmt2->store_result();
    $stmt2->bind_result($cno);
    $stmt2->fetch();   
    
    if($stmt1 = $con->prepare ("SELECT `contact_id` FROM `contact` WHERE contact_name = ?  AND contact_contact = ? AND category_id = ? AND society_id = ? limit 1")){
        $stmt1->bind_param('ssss', $name, $contactn, $cno, $sno);  // Bind "$name" to parameter.
        $stmt1->execute();    // Execute the prepared query.
        $stmt1->store_result();
    }
    if ($stmt1->num_rows == 1) {
        $errmsg_arr[] = 'Contact Already Exists';
        $errflag=true;
    }
    else{
        $stmt = $con->prepare ("INSERT INTO `contact`(`contact_name`, `contact_gender`, `contact_address`, `contact_contact`, `contact_contact2`, `contact_email`, `category_id`, `society_id`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt -> bind_param('ssssssss', $name, $gender, $address, $contactn, $contactn2, $email, $cno, $sno);
        $stmt -> execute();
        $errmsg_arr[] = 'contact Successfully added';
    }
    if($errflag){
         $_SESSION['ERRMSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    else{
        $_SESSION['MSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    header("location: addemployee.php");
	exit();
?>