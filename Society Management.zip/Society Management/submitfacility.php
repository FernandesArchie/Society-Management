<?php
    session_start();
    $errmsg_arr = array();
    $errflag = false;
	$fname = $_POST["fname"];
	$society = $_POST["society"];
    $con = new mysqli("localhost", "root", "", "society");

    if($stmt = $con->prepare ("SELECT `facility_id` FROM `facilities` WHERE facility_name = ? AND society_id = ? limit 1")){
        $stmt->bind_param('ss', $fname, $society);  // Bind "$name" to parameter.
        $stmt->execute();    // Execute the prepared query.
        $stmt->store_result();
    }
    if ($stmt->num_rows == 1) {
        $errmsg_arr[] = 'Facility already exists in the selected society';
        $errflag=true;
    }
     
    if($errflag){
         $_SESSION['ERRMSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    else{
        $stmt1 = $con->prepare ("INSERT INTO `facilities`(`facility_name`, `society_id`) VALUES (?, ?)");
        $stmt1 -> bind_param('ss', $fname, $society);
        $stmt1 -> execute();
        $errmsg_arr[] = 'Facility Successfully Added';
        $_SESSION['MSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    header("location: admin.php?con=af");
	exit();
?>