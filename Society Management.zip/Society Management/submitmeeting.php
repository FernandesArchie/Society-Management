<?php
    session_start();
    $errmsg_arr = array();
    $errflag = false;
	$reason = $_POST["textreason"];
	$location = $_POST["textloc"];
    $date = $_POST["date"];
    $time = $_POST["dtime"];
    $type = $_POST["seltype1"];
    $agenda = $_POST["txtag"];
    $society = $_POST["society"];
    $con = new mysqli("localhost", "root", "", "society");

    if($stmt = $con->prepare ("SELECT `meeting_id` FROM `meeting` WHERE meeting_date = ? AND meeting_time = ? AND society_id = ? limit 1")){
        $stmt->bind_param('sss', $date, $time, $society);  // Bind "$name" to parameter.
        $stmt->execute();    // Execute the prepared query.
        $stmt->store_result();
    }
    if ($stmt->num_rows == 1) {
        $errmsg_arr[] = 'Meeting already scheduled in the selected society on the selected date and time';
        $errflag=true;
    }
     
    if($errflag){
         $_SESSION['ERRMSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    else{
        $stmt1 = $con->prepare ("INSERT INTO `meeting`(`meeting_reason`, `meeting_location`, `meeting_date`, `meeting_time`, `meeting_type`, `meeting_agenda`, `society_id`) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt1 -> bind_param('sssssss', $reason, $location, $date, $time, $type, $agenda, $society);
        $stmt1 -> execute();
        $errmsg_arr[] = 'Meeting Successfully Scheduled';
        $_SESSION['MSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    header("location: admin.php?con=am");
	exit();
?>	