<?php
    session_start();
    $errmsg_arr = array();
    $errflag = false;
	$name = $_POST["text0"];
	$sno = $_POST["selsoc"];
    $gender = $_POST["sel2"];
    $type = $_POST["memtyp"];
    $fvno = $_POST["textloc"];
    $psno = $_POST["textps"];
    $vrno = $_POST["textvrn"];
    $uname = $_POST["textuname"];
    $pas = $_POST["textp"];
    $pass = crypt($pas);
    $con = new mysqli("localhost", "root", "","society");
    $con3 = new mysqli("localhost", "root", "","society");
    //check if flat already registered
    if($stmt = $con->prepare ("SELECT `member_name` FROM `member` WHERE flat_number = ? AND member_type = 'Owner' AND society_id = ? limit 1")){
        $stmt->bind_param('ss', $fvno, $sno);  // Bind "$name" to parameter.
        $stmt->execute();    // Execute the prepared query.
        $stmt->store_result();
    }
    if($type=="Tenant"){
        //checking if tennant already exists 
        if($stmt1 = $con->prepare ("SELECT `member_name` FROM `member` WHERE flat_number = ? AND member_type = 'Tenant' AND society_id = ? limit 1")){
            $stmt1->bind_param('ss', $fvno, $sno);  // Bind "$name" to parameter.
            $stmt1->execute();    // Execute the prepared query.
            $stmt1->store_result();
        }
        if ($stmt->num_rows != 1) {
            $errmsg_arr[] = 'Register Owner Before registering Tennant';
            $errflag=true;
        }
        else if ($stmt1->num_rows == 1) {
            $stmt1->bind_result($tname);
            $stmt1->fetch(); 
            $errmsg_arr[] = 'Tennant Already Registered as:'.$tname.' Please Remove Previous Tennant Before Adding New One.';
            $errflag=true;
        }
        register();
    }
    else{
        if ($stmt->num_rows == 1) {
            $stmt->bind_result($tname);
            $stmt->fetch();
            $errmsg_arr[] = 'Flat already registered to:'.$tname.' Please remove previous owner before adding new one.';
            $errflag=true;
        }
        register();
    }
    function register(){ 
        global $errmsg_arr, $errflag, $name, $gender, $type, $fvno, $psno, $vrno, $uname, $pass, $con, $sno, $con3;
        //check if user name already registered
        if($stmt2 = $con->prepare ("SELECT `member_id` FROM `member` WHERE member_uname = ? limit 1")){
            $stmt2->bind_param('s', $uname);  // Bind "$name" to parameter.
            $stmt2->execute();    // Execute the prepared query.
            $stmt2->store_result();
        }
        if($stmt9 = $con->prepare ("SELECT `admin_id` FROM `admin` WHERE admin_uname = ? limit 1")){
            $stmt9->bind_param('s', $uname);  // Bind "$name" to parameter.
            $stmt9->execute();    // Execute the prepared query.
            $stmt9->store_result();
        }
        if($stmt10 = $con->prepare ("SELECT `admin_id` FROM `conadmin` WHERE admin_uname = ? limit 1")){
            $stmt10->bind_param('s', $uname);  // Bind "$name" to parameter.
            $stmt10->execute();    // Execute the prepared query.
            $stmt10->store_result();
        }
        if($psno != ""){
            if($stmt3 = $con->prepare ("SELECT `parking_vnumber`, `member_id` FROM `parking` WHERE parking_number = ? AND society_id = ? limit 1")){
                $stmt3->bind_param('ss', $psno, $sno);  // Bind "$name" to parameter.
                $stmt3->execute();    // Execute the prepared query.
                $stmt3->store_result();
                $stmt3->bind_result($vpn, $mid);
                $stmt3->fetch();
            }  
            if ($stmt3->num_rows == 1) {
                if($stmt4 = $con->prepare ("SELECT `member_name`, `member_type`, `flat_number` FROM `member` WHERE member_id = ? limit 1")){
                    $stmt4->bind_param('s', $mid);  // Bind "$name" to parameter.
                    $stmt4->execute();    // Execute the prepared query.
                    $stmt4->store_result();
                    $stmt4->bind_result($vmn, $vmt, $vfn);
                    $stmt4->fetch();
                }
            if($vpn != "")
                $vpn = " having vehicle number:".$vpn;
                $errmsg_arr[] = "Parking Spot Already Allocated to:".$vmt." ".$vmn." from Flat no:".$vfn.$vpn;
                $errflag=true;
            }
            if($vrno != ""){
                if($stmt6 = $con->prepare ("SELECT `parking_number`, `member_id` FROM `parking` WHERE parking_vnumber = ? AND society_id = ? limit 1")){
                    $stmt6->bind_param('ss', $vrno, $sno);  // Bind "$name" to parameter.
                    $stmt6->execute();    // Execute the prepared query.
                    $stmt6->store_result();
                    $stmt6->bind_result($vpn, $mid);
                    $stmt6->fetch();
                }
                if ($stmt6->num_rows == 1) {
                    if($stmt8 = $con->prepare ("SELECT `member_name`, `member_type`, `flat_number` FROM `member` WHERE member_id = ? limit 1")){
                        $stmt8->bind_param('s', $mid);  // Bind "$name" to parameter.
                        $stmt8->execute();    // Execute the prepared query.
                        $stmt8->store_result();
                        $stmt8->bind_result($vmn, $vmt, $vfn);
                        $stmt8->fetch();
                    }
                    $errmsg_arr[] = "Vehicle Already registered to:".$vmt." ".$vmn." from Flat no:".$vfn." and has Parking Spot number:".$vpn;
                    $errflag=true;
                }
            }
        }
        if ($stmt2->num_rows == 1) {
            $errmsg_arr[] = 'User Name Already Registered';
            $errflag=true;
        }
        else if ($stmt9->num_rows == 1) {
            $errmsg_arr[] = 'User Name Already Registered';
            $errflag=true;
        }
        else if ($stmt10->num_rows == 1) {
            $errmsg_arr[] = 'User Name has been submitted for approval by another user, please try a different user name.';
            $errflag=true;
        }
        if(!($errflag)){
            $stmt7 = $con->prepare ("INSERT INTO `member`(`member_name`, `member_gender`, `member_uname`, `member_pword`, `flat_number`, `member_type`, `society_id`) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt7 -> bind_param('sssssss', $name, $gender, $uname, $pass, $fvno, $type, $sno);
            $stmt7 -> execute();
            if($psno != ""){
                $stmt2->execute();    // Execute the prepared query.
                $stmt2->store_result();
                $stmt2->bind_result($mid);
                $stmt2->fetch();
                $stmt5 = $con->prepare ("INSERT INTO `parking`(`parking_number`, `parking_vnumber`, `member_id`, `society_id`) VALUES  (?, ?, ?, ?)");
                $stmt5 -> bind_param('ssss', $psno, $vrno, $mid, $sno);
                $stmt5 -> execute();    
            }
            $errmsg_arr[]=$type.' Successfully Registered';
        }
    } 
    
    if($errflag){
         $_SESSION['ERRMSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    else{
        $_SESSION['MSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    header("location: admin.php?con=adm");
		  exit();
?>