<html>
    <head>
        <script>
        function validate() {
                var psno = document.form.textps;
                var vrno = document.form.textvrn;
                var iChars1 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?_";
                var numbers = /^[0-9]+$/;
                if(psno.value == ""){
                    alert("Please Enter the Parking spot number");
                    psno.focus();
                    return false;
                }
                if(psno.value.match(" ")) {
                    alert("Parking Spot number Should not contain spaces");
                    psno.focus();
                    return false;
                }
                for (var i = 0; i < vrno.value.length; i++) {
                    if (iChars1.indexOf(vrno.value.charAt(i)) != -1) {
                        alert ("Vehicle Registration Number can only contain Alphabets, Numbers and these characters:\n\".\"");
                        vrno.focus();
                        return false;
                    }
                }
                if (psno.value.match(numbers))  
                {  
                    alert("Parking Spot Number Should Contain Alphabets");
                    psno.focus();
                    return false;
                }
                if (vrno.value.match(numbers))  
                {  
                    alert("Vehicle Registration Number Should Contain Alphabets");
                    vrno.focus();
                    return false;
                }
                if (psno.value.length>5){
                    alert("Parking Spot Number Cannot Contain more than 5 characters");
                    psno.focus();
                    return false;
                }
                if (vrno.value.length>13){
                    alert("Vehicle Registration Number Cannot Contain more than 13 characters");
                    vrno.focus();
                    return false;
                }
                return true;
            }
            function validate1() {
                var vrno = document.form.textvrn;
                var iChars1 = "!@#$%^&*()+=-[]\\\';,/{}|\":<>?_";
                var numbers = /^[0-9]+$/;
                if(vrno.value == ""){
                    alert("Please Enter the Vehicle Registration number");
                    vrno.focus();
                    return false;
                }
                for (var i = 0; i < vrno.value.length; i++) {
                    if (iChars1.indexOf(vrno.value.charAt(i)) != -1) {
                        alert ("Vehicle Registration Number can only contain Alphabets, Numbers and these characters:\n\".\"");
                        vrno.focus();
                        return false;
                    }
                }
                if (vrno.value.match(numbers))  
                {  
                    alert("Vehicle Registration Number Should Contain Alphabets");
                    vrno.focus();
                    return false;
                }
                if (vrno.value.length>13){
                    alert("Vehicle Registration Number Cannot Contain more than 13 characters");
                    vrno.focus();
                    return false;
                }
                return true;
            }
        </script>
    </head>
    <body>
        <center>
<?php
    $errmsg_arr = array();
	$con = new mysqli("localhost", "root", "", "society");
    if(isset($_POST["alter"])){
        $id = $_POST["alter"];
        $errflag = false;
        if($stmt = $con->prepare ("SELECT `member_name` FROM `member` WHERE `member_id` = ? limit 1")){
            $stmt->bind_param('s', $id);  // Bind "$name" to parameter.
            $stmt->execute();// Execute the prepared query.
            $stmt->bind_result($mn);
            $stmt->fetch();
        }
		echo "<form name=\"form\" action=\"subparking.php\" method=\"post\">";
         echo"<input type=\"hidden\" name=\"id\" value=\"".$id."\">";
		echo "<h2>Allot Parking For ".$mn."</h2>";
			echo "<table><tr>";
					echo "<td>Parking Spot Number:<span style=\"color: red;\">*</span></td>";
					echo "<td><input type=\"text\" name=\"textps\"></td>";
				echo "</tr><tr>";
					echo"<td>Vehicle Registration Number:</td>";
					echo"<td><input type=\"text\" name=\"textvrn\"></td>";
				echo "</tr><tr>";
                   echo "<td colspan=\"2\"><center><input type=\"submit\" value=\"Register\" onClick=\"return validate()\"></center></td>";
				echo "</tr></table>";
		echo "</form>";
    }
    else if(isset($_POST["delete"])){
        $id = $_POST["delete"];
        if($stmt = $con->prepare ("DELETE FROM `parking` WHERE `parking_id` = ?")){
            $stmt->bind_param('s', $id);  // Bind "$name" to parameter.
            $stmt->execute();
            $errmsg_arr[]='Parking Spot Successfully Deleted';
        }
        $_SESSION['MG_ARR']=$errmsg_arr;
        session_write_close();
        echo"<script>";
                echo"window.location.href ='admin.php?con=ap';";
        echo"</script>";
        exit();
    }
    else{
        $id = $_POST["edit"];
        echo "<form name=\"form\" action=\"editparking.php\" method=\"post\">";
        echo"<input type=\"hidden\" name=\"id\" value=\"".$id."\">";
        if($stmt = $con->prepare ("SELECT `parking_number`, `parking_vnumber` FROM `parking` WHERE `parking_id` = ? limit 1")){
            $stmt->bind_param('s', $id);  // Bind "$name" to parameter.
            $stmt->execute();// Execute the prepared query.
            $stmt->bind_result($ps, $pvn);
            $stmt->fetch();
        }
        echo "<h2>Edit Vehicle Number For Parking Spot ".$ps."</h2>";
        echo "<table><tr><td>Vehicle Registration Number:</td><td><input type='text' name='textvrn' value='".$pvn."'></td></tr>";
        echo "<tr><td colspan='2'><center><input type=\"submit\" value=\"Register\" onClick=\"return validate1()\"></center></td></tr></table>";
        echo "</form>";
    }
?>
	</center>
    </body>
</html>