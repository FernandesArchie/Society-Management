<?php
    session_start();
    $errmsg_arr = array();
    $errflag = false;
$row= false;
	$name = $_POST["text1"];
	$locality = $_POST["textloc"];
    $con = new mysqli("localhost", "root", "","society");
    if($stmt = $con->prepare ("SELECT `society_name`, `society_locality` FROM `society` WHERE society_name = ? limit 1")){
        $stmt->bind_param('s', $name);  // Bind "$name" to parameter.
        $stmt->execute();    // Execute the prepared query.
        $stmt->store_result();
        // get variables from result.
        $stmt->bind_result($dbname, $dblocal);
        $stmt->fetch();
    }
    if ($stmt->num_rows == 1) {
         if ($dblocal == $locality){
            $errmsg_arr[] = 'Society Already Exists';
            $errflag=true;
         }
    }
    else{            
        $stmt = $con->prepare ("INSERT INTO `society`(`society_name`, `society_locality`) VALUES (?, ?)");
        $stmt -> bind_param('ss', $name, $locality);
        $stmt -> execute();
        $errmsg_arr[] = 'Society Successfully Added';
    }
    if($errflag){
         $_SESSION['ERRMSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    else{
        $_SESSION['MSG_ARR']=$errmsg_arr;
        session_write_close();
    }
    header("location: admin.php?con=as");
		  exit();
?>