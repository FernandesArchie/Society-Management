<?php
    session_start();
    $errmsg_arr = array();
	$con = new mysqli("localhost", "root", "", "society");
    $id = $_POST["id"];
    $psno = $_POST["textps"];
    $vrno = $_POST["textvrn"];
    $errflag = false;
    if($stmt = $con->prepare ("SELECT `society_id` FROM `member` WHERE `member_id` = ? limit 1")){
        $stmt->bind_param('s', $id);  // Bind "$name" to parameter.
        $stmt->execute();    // Execute the prepared query.
        $stmt->store_result();
        $stmt->bind_result($sno);
        $stmt->fetch();
    }
    if($stmt3 = $con->prepare ("SELECT `parking_vnumber`, `member_id` FROM `parking` WHERE parking_number = ? AND society_id = ? limit 1")){
        $stmt3->bind_param('ss', $psno, $sno);  // Bind "$name" to parameter.
        $stmt3->execute();    // Execute the prepared query.
        $stmt3->store_result();
        $stmt3->bind_result($vpn, $mid);
        $stmt3->fetch();
    }
    if ($stmt3->num_rows == 1) {
        if($stmt4 = $con->prepare ("SELECT `member_name`, `member_type`, `flat_number` FROM `member` WHERE member_id = ? limit 1")){
            $stmt4->bind_param('s', $mid);  // Bind "$name" to parameter.
            $stmt4->execute();    // Execute the prepared query.
            $stmt4->store_result();
            $stmt4->bind_result($vmn, $vmt, $vfn);
            $stmt4->fetch();
        }
        if($vpn != "")
            $vpn = " having vehicle number:".$vpn;
        $errmsg_arr[] = "Parking Spot Already Allocated to:".$vmt." ".$vmn." from Flat no:".$vfn.$vpn;
        $errflag=true;
    }
    if($vrno != ""){
        if($stmt6 = $con->prepare ("SELECT `parking_number`, `member_id` FROM `parking` WHERE parking_vnumber = ? AND society_id = ? limit 1")){
            $stmt6->bind_param('ss', $vrno, $sno);  // Bind "$name" to parameter.
            $stmt6->execute();    // Execute the prepared query.
            $stmt6->store_result();
            $stmt6->bind_result($vpn, $mid);
            $stmt6->fetch();
        }
        if ($stmt6->num_rows == 1) {
            if($stmt8 = $con->prepare ("SELECT `member_name`, `member_type`, `flat_number` FROM `member` WHERE member_id = ? limit 1")){
                $stmt8->bind_param('s', $mid);  // Bind "$name" to parameter.
                $stmt8->execute();    // Execute the prepared query.
                $stmt8->store_result();
                $stmt8->bind_result($vmn, $vmt, $vfn);
                $stmt8->fetch();
            }
            $errmsg_arr[] = "Vehicle Already registered to:".$vmt." ".$vmn." from Flat no:".$vfn." and has Parking Spot number:".$vpn;
            $errflag=true;
        }
    }
    if($errflag){
        $_SESSION['ERR_ARR'] = $errmsg_arr;
        session_write_close();
        header("location: admin.php?con=ap");
        exit();
    }
    else{
        $stmt5 = $con->prepare ("INSERT INTO `parking`(`parking_number`, `parking_vnumber`, `member_id`, `society_id`) VALUES  (?, ?, ?, ?)");
        $stmt5 -> bind_param('ssss', $psno, $vrno, $id, $sno);
        $stmt5 -> execute();
        $errmsg_arr[] = "Parking Successfully Alloted";
        $_SESSION['MG_ARR'] = $errmsg_arr;
        session_write_close();
        header("location: admin.php?con=ap");
        exit();
    }
?>